<?php
/**
 * Class with shortcodes
 */

class Mauna_Shortcodes
{
	public function __construct()
	{
		remove_shortcode('gallery', 'gallery_shortcode');
		add_shortcode('mauna_wp_gallery', 'gallery_shortcode');

		add_shortcode('gallery', array($this,'mauna_gallery_shortcode_wrapper'));
		add_action('admin_init', array($this,'mauna_add_button_columns'));
		add_action( 'admin_init', array($this,'mauna_editor_styles' ));
		add_shortcode( 'column', array($this,'mauna_shortcode_columns' ));
		add_filter('mce_buttons_2', array($this,'mauna_formats_button'));
		add_filter('tiny_mce_before_init', array($this,'mauna_mce_before_init_insert_formats'));
	}


	/* Tiny MCE/SU shorcodes init */
	public function tiny_MCE_shortcodes_init()
	{
		define( 'SU_PLUGIN_FILE', MAUNA_PLUG_DIR .'SU_shortcodes/');
		define( 'SU_PLUGIN_ASSETS', MAUNA_PLUG_DIR_URI .'SU_shortcodes/assets/');
		define( 'SU_PLUGIN_VERSION', '4.9.3' );
		define( 'SU_ENABLE_CACHE', false );

		// Includes
		require_once SU_PLUGIN_FILE .'inc/core/load.php';
		require_once SU_PLUGIN_FILE .'inc/core/assets.php';
		require_once SU_PLUGIN_FILE .'inc/core/shortcodes.php';
		require_once SU_PLUGIN_FILE .'inc/core/tools.php';
		require_once SU_PLUGIN_FILE .'inc/core/data.php';
		require_once SU_PLUGIN_FILE .'inc/core/generator-views.php';
		require_once SU_PLUGIN_FILE .'inc/core/generator.php';	
	}

	function mauna_gallery_shortcode_wrapper($atts) {
		$attsString = '';
		$output = '';
		$link = '';
		if($atts != '' && is_array($atts)) {
			foreach($atts as $key => $value) {
				$attsString .= $key.'="'.$value.'" ';
			}
			$link = '';

			if(isset($atts['link']) && $atts['link']) {
				$link = 'file';
			}

		}
		if($link == 'file') {
			$output.= '<div class="mauna-gallery gallery-lightbox-wrapper">';
		} else {
			$output.= '<div class="mauna-gallery">';
		}
		$output .= do_shortcode( '[mauna_wp_gallery '.$attsString.']' );
		// if(isset($atts['link']) && $atts['link'] == 'file') {
			$output .= '</div>';
		// }
		return $output;
	}


	function mauna_add_button_columns() {
		if (current_user_can('edit_posts') && current_user_can('edit_pages')) {
			add_filter('mce_external_plugins', array($this,'mauna_register_tinymce_javascript'));
			add_filter('mce_buttons', array($this,'mauna_columns_button'));
		}
	}

	function mauna_columns_button($buttons) {
		array_push( $buttons, 'columns' );

		return $buttons;
	}

	function mauna_register_tinymce_javascript( $plugin_array ) {
	   $plugin_array['columns'] = get_template_directory_uri(). '/library/tinymce/shortcode_columns.js';
	   return $plugin_array;
	}

	/**
	 * Registers an editor stylesheet
	 */
	function mauna_editor_styles() {
	    add_editor_style(  get_template_directory_uri().'/library/tinymce/shortcode_columns.css' );
	}



	// Extended subscription function with subscription type variable
	function mauna_shortcode_columns( $atts, $content ) {
	    // $atts = shortcode_atts( array('class'=>''), $atts );
	    $content = apply_filters('the_content', $content);
	   	return $content;
	}



	// Callback function to insert 'styleselect' into the $buttons array
	function mauna_formats_button($buttons) {
		array_unshift($buttons, 'styleselect');

		return $buttons;
	}

	function mauna_mce_before_init_insert_formats($init_array) {
		// Define the style_formats array

		$style_formats = array(  
			// Each array child is a format with it's own settings		
			array(  
				'title' => 'Font weight 100',  
				'inline' => 'span',  
				'styles' => array('font-weight' => '100'),
			),
			array(  
				'title' => 'Font weight 200',  
				'inline' => 'span',  
				'styles' => array('font-weight' => '200'),
			),
			array(  
				'title' => 'Font weight 300',  
				'inline' => 'span',  
				'styles' => array('font-weight' => '300'),
			),
			array(  
				'title' => 'Font weight 400',  
				'inline' => 'span',  
				'styles' => array('font-weight' => '400'),
			),
			array(  
				'title' => 'Font weight 500',  
				'inline' => 'span',  
				'styles' => array('font-weight' => '500'),
			),
			array(  
				'title' => 'Font weight 600',  
				'inline' => 'span',  
				'styles' => array('font-weight' => '600'),
			),
			array(  
				'title' => 'Font weight 700',  
				'inline' => 'span',
				'styles' => array('font-weight' => '700'),
			),
			array(  
				'title' => 'Font weight 800',  
				'inline' => 'span',
				'styles' => array('font-weight' => '800'),
			),
			array(  
				'title' => 'Font weight 900',  
				'inline' => 'span',  
				'styles' => array('font-weight' => '900'),
			),
		);
		// Insert the array, JSON ENCODED, into 'style_formats'
		$init_array['style_formats'] = json_encode( $style_formats );  
		
		return $init_array;
	}



}