<?php
class Mauna_Post_Types
{
	public function __construct()
	{
		add_action('init', array($this, 'create_post_types') );
		add_filter( 'pre_get_posts', array($this, 'mauna_search_filter' ));

		add_action('admin_head', array($this, 'mauna_admin_column_width'));
		add_filter('manage_edit-mauna_portfolio_columns', array($this, 'mauna_edit_mauna_portfolio_columns'));
		add_action('manage_mauna_portfolio_posts_custom_column', array($this, 'mauna_manage_mauna_portfolio_columns'), 10, 2);
		add_filter('manage_edit-mauna_promotion_columns', array($this, 'mauna_edit_mauna_promotion_columns'));
		add_action('manage_mauna_promotion_posts_custom_column', array($this, 'mauna_manage_mauna_promotion_columns'), 10, 2);
		add_filter('manage_edit-mauna_about_columns', array($this, 'mauna_edit_mauna_about_columns'));
		add_action('manage_mauna_about_posts_custom_column', array($this, 'mauna_manage_mauna_about_columns'), 10, 2);

		add_filter('manage_mauna_portfolio_item_posts_columns', array($this, 'mauna_add_image_column' ));
		add_filter('manage_mauna_portfolio_item_posts_columns', array($this, 'mauna_add_category_column' ));
		add_filter('manage_mauna_promotion_item_posts_columns', array($this, 'mauna_add_image_column' ));
		add_filter('manage_mauna_promotion_item_posts_columns', array($this, 'mauna_add_category_column' ));
		add_filter('manage_mauna_about_item_posts_columns', array($this, 'mauna_add_image_column' ));
		add_filter('manage_mauna_about_item_posts_columns', array($this, 'mauna_add_category_column' ));

		add_filter('manage_menu_item_posts_columns', array($this, 'mauna_add_category_column' ));
		add_filter('manage_mauna_day_posts_columns', array($this, 'mauna_add_day_column' ));

		add_action('manage_posts_custom_column', array($this, 'display_posts_image' ), 10, 2);
		add_action('manage_posts_custom_column', array($this, 'display_category' ), 10, 2);
		add_action('manage_posts_custom_column', array($this, 'mauna_display_day'), 10, 2);

	}
	

	public function create_post_types()
	{
		// $redux = mauna_get_global_option_redux();
		global $redux;

		if(is_null($redux) && function_exists('mauna_get_global_option_redux')) {
			$redux = mauna_get_global_option_redux();
		}

		/**
		 *  Portfolio Categories/Taxonomy
		 */

		register_taxonomy(
			'mauna_portfolio_categories',
			'mauna_portfolio_item',
			array(
				'hierarchical'	=> true,
				'label'			=> __( 'Portfolio Categories', 'mauna' ),
				'query_var'		=> true,
				'show_ui'		=> true,
			)
		);


		if(isset($redux['mauna_portfolio_single_slug']) && $redux['mauna_portfolio_single_slug'] != '') {
			$portfolioSlug = $redux['mauna_portfolio_single_slug'];
		} else {
			$portfolioSlug = 'mauna_portfolio_item';
		}

		register_post_type(
			'mauna_portfolio_item',
			array(
				'labels' => array(
					'name' 			=> __('Portfolio', 'mauna'),
					'singular_name' => __('Portfolio', 'mauna'),
					'all_items'		=> __('Portfolio Items', 'mauna'),
					'add_new'		=> __('Add Portfolio Item', 'mauna'),
					'add_new_item'	=> __('Add Portfolio Item', 'mauna'),
					'edit_item'		=> __('Edit Portfolio Item', 'mauna')
				),
				'public'		=> true,
				'publicly_queryable' => true,
				'exclude_from_search' => false,
				'query_var' => true,
				'show_ui'		=> true,
				'can_export' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'supports'		=> array('title', 'editor', 'thumbnail'),
				'taxonomies'	=> array('mauna_portfolio_categories', 'post_tag'),
				'rewrite'		=> array(
					'slug'		=> $portfolioSlug,
					'with_front' => true,
					'hierarchical'	=> true,
				),
			)
		);

		/**
		 *  About Categories/Taxonomy
		 */

		register_taxonomy(
			'mauna_about_categories',
			'mauna_about_item',
			array(
				'hierarchical'	=> true,
				'label'			=> __( 'About Categories', 'mauna' ),
				'query_var'		=> true,
				'show_ui'		=> true,
			)
		);

		if(isset($redux['mauna_about_slug']) && $redux['mauna_about_slug'] != '') {
			$aboutSlug = $redux['mauna_about_slug'];
		} else {
			$aboutSlug = 'mauna_about_item';
		}

		register_post_type(
			'mauna_about_item',
			array(
				'labels' => array(
					'name' 			=> __('About', 'mauna'),
					'singular_name' => __('About', 'mauna'),
					'all_items'		=> __('About Items', 'mauna'),
					'add_new'		=> __('Add About Item', 'mauna'),
					'add_new_item'	=> __('Add About Item', 'mauna'),
					'edit_item'		=> __('Edit About Item', 'mauna')
				),
				'public'		=> true,
				'publicly_queryable' => true,
				'exclude_from_search' => false,
				'query_var' => true,
				'show_ui'		=> true,
				'can_export' => true,
				'capability_type' => 'post',
				'has_archive' => false,
				'supports'		=> array('title', 'editor', 'thumbnail'),
				'taxonomies'	=> array('mauna_about_categories'),
				// 'rewrite'		=> array(
				// 	'slug'		=> 'slug',
				// 	'with_front' => true,
				// 	'hierarchical'	=> true,
				// ),
				'rewrite'		=> array(
					'slug'		=> $aboutSlug,
					'with_front' => true,
					'hierarchical'	=> true,
				),
			)
		);
		/**
		 *  Promotion/News Categories/Taxonomy
		 */

		register_taxonomy(
			'mauna_promotion_categories',
			'mauna_promotion_item',
			array(
				'hierarchical'	=> true,
				'label'			=> __( 'Promotion Categories', 'mauna' ),
				'query_var'		=> true,
				'show_ui'		=> true,
			)
		);


		if(isset($redux['mauna_promotion_single_slug']) && $redux['mauna_promotion_single_slug'] != '') {
			$promotionSlug = $redux['mauna_promotion_single_slug'];
		} else {
			$promotionSlug = 'mauna_promotion_item';
		}

		register_post_type(
			'mauna_promotion_item',
			array(
				'labels' => array(
					'name' 			=> __('Promotion', 'mauna'),
					'singular_name' => __('Promotion', 'mauna'),
					'all_items'		=> __('Promotion Items', 'mauna'),
					'add_new'		=> __('Add Promotion Item', 'mauna'),
					'add_new_item'	=> __('Add Promotion Item', 'mauna'),
					'edit_item'		=> __('Edit Promotion Item', 'mauna')
				),
				'public'		=> true,
				'publicly_queryable' => true,
				'exclude_from_search' => false,
				'query_var' => true,
				'show_ui'		=> true,
				'can_export' => true,
				'capability_type' => 'post',
				'has_archive' => false,
				'supports'		=> array('title', 'editor', 'thumbnail'),
				'taxonomies'	=> array('mauna_promotion_categories'),
				'rewrite'		=> array(
					'slug'		=> $promotionSlug,
					'with_front' => true,
					'hierarchical'	=> true,
				),
			)
		);


		if (class_exists('MultiPostThumbnails')) {
			new MultiPostThumbnails(
				array(
					'label' => 'Hover image',
					'id' => 'hover-image',
					'post_type' => 'mauna_portfolio_item'
				)
			);
		}


	}

	public function mauna_admin_column_width() {
		if (strstr($_SERVER['SCRIPT_NAME'], 'edit.php')) {
			echo '<style type="text/css">.column-image { text-align: left; width:60px !important; overflow:hidden } .column-title, #the-list .column-date, .column-category { cursor: default !important; }</style>';	
		}
	}

	public function mauna_edit_mauna_portfolio_columns($columns) {
		$columns = array(
			'cb' => '<input type="checkbox" />',
			'image' => __('Image', 'mauna'),
			'title' => __('Title', 'mauna'),
			'category' 	=> __('Category', 'mauna'),
			'date' 		=> __('Date', 'mauna')			
		);

		if ($columns['icl_translations']) {
			$col[] = array($columns['icl_translations']);
		}

		// $col[] = array(
		// 	'category' => __('Categories', 'mauna'),
		// 	'date' => __('Date', 'mauna')
		// );

		return $columns;
	}


	public function mauna_edit_mauna_about_columns($columns) {
		$columns = array(
			'cb' => '<input type="checkbox" />',
			'image' => __('Image', 'mauna'),
			'title' => __('Title', 'mauna'),
			'category' 	=> __('Category', 'mauna'),
			'date' 		=> __('Date', 'mauna')			
		);

		if ($columns['icl_translations']) {
			$col[] = array($columns['icl_translations']);
		}

		// $col[] = array(
		// 	'category' => __('Categories', 'mauna'),
		// 	'date' => __('Date', 'mauna')
		// );

		return $columns;
	}

	public function mauna_manage_portfolio_columns($column, $post_id) {
		global $post;

		switch ($column) {

			case 'category':

				$item_category = get_the_terms($post_id, 'mauna_portfolio_categories');

				$categories_output = '';
				if (is_array($item_category)) {
					foreach ($item_category as $cat_obj) {
						$cat_link = get_term_link($cat_obj);
						$categories_output .= '<a href="'. admin_url('edit.php?post_type=portfolio&mauna_portfolio_categories=' . $cat_obj->slug) .'" title="'. $cat_obj->slug .'">'. $cat_obj->name .'</a>, ';
					}
				}
				
				echo rtrim($categories_output, ', ');

				break;

			case 'image':
				$image = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'thumbnail');

				if (!empty($image[0])) {
					echo '<img src="' . $image[0] . '" style="width:50px;" />';
				}

				break;

			default :
				break;
		}
	}

	public function mauna_manage_promotion_columns($column, $post_id) {
		global $post;

		switch ($column) {

			case 'category':

				$item_category = get_the_terms($post_id, 'mauna_promotion_categories');

				$categories_output = '';
				if (is_array($item_category)) {
					foreach ($item_category as $cat_obj) {
						$cat_link = get_term_link($cat_obj);
						$categories_output .= '<a href="'. admin_url('edit.php?post_type=promotion&mauna_promotion_categories=' . $cat_obj->slug) .'" title="'. $cat_obj->slug .'">'. $cat_obj->name .'</a>, ';
					}
				}
				
				echo rtrim($categories_output, ', ');

				break;

			case 'image':
				$image = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'thumbnail');

				if (!empty($image[0])) {
					echo '<img src="' . $image[0] . '" style="width:50px;" />';
				}

				break;

			default :
				break;
		}
	}
	public function mauna_manage_about_columns($column, $post_id) {
		global $post;

		switch ($column) {

			case 'category':

				$item_category = get_the_terms($post_id, 'mauna_about_categories');

				$categories_output = '';
				if (is_array($item_category)) {
					foreach ($item_category as $cat_obj) {
						$cat_link = get_term_link($cat_obj);
						$categories_output .= '<a href="'. admin_url('edit.php?post_type=about&mauna_about_categories=' . $cat_obj->slug) .'" title="'. $cat_obj->slug .'">'. $cat_obj->name .'</a>, ';
					}
				}
				
				echo rtrim($categories_output, ', ');

				break;

			case 'image':
				$image = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'thumbnail');

				if (!empty($image[0])) {
					echo '<img src="' . $image[0] . '" style="width:50px;" />';
				}

				break;

			default :
				break;
		}
	}


	/* Display custom image column */
	public function display_posts_image($column, $post_id) {
		$type = get_post_type($post_id);
		if ($type == 'mauna_portfolio_item' || $type == 'mauna_about_item' || $type == 'mauna_promotion_item') {
			if ($column == 'image') {
				$image = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'thumbnail');
				if (!empty($image[0])) {
					echo '<img src="' . $image[0] . '" style="width:50px;" />';
				}
			}
		}

	}

	public function display_category($column, $post_id) {
		$type = get_post_type($post_id);
		if ($type == 'mauna_portfolio_item') {
			if ($column == 'category') {
				$categories = get_the_terms($post_id, 'mauna_portfolio_categories');
				if($categories !== false) {
					foreach($categories as $cat) {
						$url = get_edit_term_link( $cat->term_id, 'mauna_portfolio_categories' );
						echo '<strong><a class="row-title" href="'.$url.'" title="Edit '.htmlspecialchars($cat->name).' ">'.$cat->name.'</a>, </strong>';
					}
				}
			}
		}
		if ($type == 'mauna_promotion_item') {
			if ($column == 'category') {
				$categories = get_the_terms($post_id, 'mauna_promotion_categories');
				if($categories !== false) {
					foreach($categories as $cat) {
						$url = get_edit_term_link( $cat->term_id, 'mauna_promotion_categories' );
						echo '<strong><a class="row-title" href="'.$url.'" title="Edit '.htmlspecialchars($cat->name).' ">'.$cat->name.'</a>, </strong>';
					}
				}
			}
		}
		if ($type == 'mauna_about_item') {
			if ($column == 'category') {
				$categories = get_the_terms($post_id, 'mauna_about_categories');
				if($categories !== false) {
					foreach($categories as $cat) {
						$url = get_edit_term_link( $cat->term_id, 'mauna_about_categories' );
						echo '<strong><a class="row-title" href="'.$url.'" title="Edit '.htmlspecialchars($cat->name).' ">'.$cat->name.'</a>, </strong>';
					}
				}
			}
		}
	}

	/* Add custom column to post list */
	public function mauna_add_image_column($columns) {
		$res = array_slice($columns, 0, 1, true) + array("image" => "Image") + array_slice($columns, 1, count($columns) - 1, true) ;
		return $res;
	}

	public function mauna_add_category_column($columns) {
		$res = array_slice($columns, 0, 3, true) + array("category" => "Category") + array_slice($columns, 1, count($columns) - 1, true) ;
		return $res;
		
	}

	public function mauna_add_day_column($columns) {
		$res = array_slice($columns, 0, 2, true) + array("day" => "Day") + array_slice($columns, 1, count($columns) - 1, true) ;
		return $res;
	}

	public function mauna_display_day($column, $post_id) {
		$type = get_post_type($post_id);
		if ($type == 'mauna_day') {
			if ($column == 'day') {
				$dayType = get_post_meta($post_id, 'mauna_day_type', true);
				if($dayType === '') {
					$meta = get_post_meta($post_id, 'mauna_day_weekday', true);
					if($meta !== false) {
						echo self::mauna_get_weekday_name($meta);
					}
				} else {
					$meta = get_post_meta($post_id, 'mauna_day_custom_date', true);
					if($meta !== false) {
						echo $meta;
					}
				}
			}
		}
	}

	// Search filter
	function mauna_search_filter($query) {
	if ($query->is_search) {
		$query->set('post_type', array('post') );
	}
		return $query;
	}

	private function mauna_get_weekday_name($day) {
		if($day == '')
			return false;

		$days = array(
			1 => __('Monday', 'mauna'),
			2 => __('Tuesday', 'mauna'),
			3 => __('Wednesday', 'mauna'),
			4 => __('Thursday', 'mauna'),
			5 => __('Friday', 'mauna'),
			6 => __('Saturday', 'mauna'),
			7 => __('Sunday', 'mauna'),		
		);
		$day = $days[$day];
		return $day;
	}

}

add_filter('pre_get_posts', 'query_post_type');
function query_post_type($query) {
  if(is_category() || is_tag()) {
    $post_type = get_query_var('post_type');
	if($post_type)
	    $post_type = $post_type;
	else
	    $post_type = array('post','mauna_portfolio_item'); // replace cpt to your custom post type
    $query->set('post_type',$post_type);
	return $query;
    }
}