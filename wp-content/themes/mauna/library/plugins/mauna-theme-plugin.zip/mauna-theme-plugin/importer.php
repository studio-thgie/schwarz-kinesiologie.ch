<?php
if (!function_exists ('add_action')) {
	header('Status: 403 Forbidden');
	header('HTTP/1.1 403 Forbidden');

	exit();
}

require_once(ABSPATH . '/wp-admin/includes/media.php');
require_once(ABSPATH . '/wp-admin/includes/file.php');
require_once(ABSPATH . '/wp-admin/includes/image.php');

class Demo_Importer {

	public $message = "";
	public $attachments = false;
	public $imagesURL = "";

	public function show_import() {
	?>
	<form method="post" action="" id="importContentForm">
		<table class="form-table">
			<tbody>
				<tr class="form-field">
					<td scope="row" colspan="2">
						<div class="import_load">
							<br/>
							<div class="html5-progress-bar">
								<div class="progress-bar-wrapper">
									<progress id="progressbar" value="0" max="100"></progress>
								</div>
								<div class="progress-value">0%</div>
								<div class="progress-bar-message">
								</div>
							</div>
						</div>
					</td>
				</tr>
				<tr class="form-field">
					<td colspan="2">
						<br/>
						<input type="submit" class="button button-primary" value="Import" name="import" id="import_demo_data" />
					</td>
				</tr>

			</tbody>
		</table>
	</form>

	<script type="text/javascript">
		jQuery(document).ready(function() {

			jQuery(document).on('click', '#import_demo_data', function(e) {
				e.preventDefault();

				if (confirm("<?php esc_html_e('Make sure you activated recommended plugins! Are you sure, you want to import Demo Data now? ', 'mauna'); ?>")) {
					jQuery('#redux_ajax_overlay').show(0);
					jQuery('.import_load').css('display','block');

					var progressbar = jQuery('#progressbar');
					var import_demo = 'demo2';
					import_demo = 'demo'+jQuery('#mauna_redux-mauna_demo_select input:checked').val()
					jQuery('.progress-value').html((50) + '%');
					progressbar.val(50);
					jQuery.ajax({
						type: 'POST',
						url: ajaxurl,
						data: {
							action: 'mauna_import',
							demo: import_demo,
							type: jQuery('input[name="mauna_redux[mauna_demo_content]"]:checked').val()
						},
						success: function(data, textStatus, XMLHttpRequest) {
							jQuery('.progress-value').html((75) + '%');
							progressbar.val(75);
							setTimeout(function(){
								jQuery('.progress-bar-message').html('<div class="alert alert-success">Import is completed.</div>');
								jQuery('.progress-value').html((100) + '%');
								progressbar.val(100);
								document.location.reload();
							}, 3000);

						},
						error: function(MLHttpRequest, textStatus, errorThrown){
						}
					});
				}

				return false;
			});
		});
	</script>
	<?php
	}

	public function import($file) {
		global $wpdb;

		WP_Filesystem();
        global $wp_filesystem;

		$file_content = "";
		$file_for_import = get_template_directory() . '/library/import/' . $file;
		
		if (file_exists($file_for_import)) {
			$file_content = $wp_filesystem->get_contents($file_for_import);
		} else {
			$this->message = __("File doesn't exist", 'mauna');
		}

		if ($file_content) {
			$prefix = $wpdb->prefix;
			$site_url = site_url();

			$theme_name = get_template_directory_uri();
			$themeName = explode('/', $theme_name);
			$theme_name = $themeName[count($themeName)-1];

			if (substr($site_url, -1) != '/') {
				$site_url = $site_url . "/";
			}

			// yopress
			if (is_child_theme()) {
				$file_content = str_replace('[::theme_mods::]', 'theme_mods_mauna-child', $file_content);
			} else {
				$file_content = str_replace('[::theme_mods::]', 'theme_mods_mauna', $file_content);
			}

			// replace database prefix
			$file_content = str_replace('[::prefix::]', $prefix, $file_content);
			// replace site url
			$file_content = str_replace('[::site_url::]', $site_url, $file_content);
			//replace year and month

			$file_content = str_replace('[::year::]', date('Y'), $file_content);
			$file_content = str_replace('[::month::]', date('m'), $file_content);

			$file_content = str_replace('[::theme_name::]', $theme_name, $file_content);

			$dbhost = DB_HOST;
			$dbport = 3306;

			if (strstr($dbhost, '.sock', true)) {
				//localhost:/tmp/mysql5d.sock
				$s = explode(':', $dbhost);
				$dbhost = $s[0];
				$socket = $s[1];
				$link = mysqli_connect($dbhost, DB_USER, DB_PASSWORD, DB_NAME, 3306, $socket);
			} else {
				$parts = explode(":", $dbhost);

				if (isset($parts[0])) {
					$dbhost = $parts[0];	
				} else {
					$dbhost = DB_HOST;
				}
				
				if (isset($parts[1])) {
					$dbport = intval($parts[1]);
				} else {
					$dbport = 3306;
				}

				$link = mysqli_connect($dbhost, DB_USER, DB_PASSWORD, DB_NAME, $dbport);
			}

			/* check connection */
			if (mysqli_connect_errno()) {
			    printf("Connect failed: %s\n", mysqli_connect_error());
			    exit();
			}

			/* execute multi query */
			if (mysqli_multi_query($link, $file_content)) {
				 echo "Success\n\n";
				 echo "$file_content";
			} else {
				 echo "Fail";
			}
		}
	}

	public function import_redux($file) {
		WP_Filesystem();
        global $wp_filesystem;
		$file_content = "";
		$file_for_import = get_template_directory() . '/library/import/' . $file;
		if (file_exists($file_for_import)) {
			$file_content = $wp_filesystem->get_contents($file_for_import);
		} else {
			$this->message = __("File doesn't exist", 'mauna');
		}
		if ($file_content) {
			$file_content = json_decode($file_content, true);
			update_option('mauna_redux', $file_content, 'yes');
		}
	}
}

?>