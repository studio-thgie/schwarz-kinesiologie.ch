<?php 
/**
 * Plugin Name: Mauna Theme Plugin
 * Plugin URI: http://puruno.com/
 * Description: Custom post types and functionality required in theme
 * Version: 1.2.2
 * Author: PURUNO
 * Author URI: http://themeforest.net/user/puruno
 * License: Themeforest Split Licence
 */

define('MAUNA_PLUG_DIR', plugin_dir_path(__FILE__));
define('MAUNA_PLUG_DIR_URI', plugin_dir_url( __FILE__ ));

include_once MAUNA_PLUG_DIR.'class-post-types.php';
include_once MAUNA_PLUG_DIR.'class-mauna-shortcodes.php';
include_once MAUNA_PLUG_DIR.'menu-images.php';
include_once MAUNA_PLUG_DIR.'multiple-post-thumbnails/multi-post-thumbnails.php';
include_once MAUNA_PLUG_DIR.'redux-metaboxes-config.php';
include_once MAUNA_PLUG_DIR.'redux/redux-framework.php';
include_once MAUNA_PLUG_DIR.'redux-global.php';
include_once MAUNA_PLUG_DIR.'importer.php';

class Mauna_Utility_Plugin {
	private static $instance = null;
	protected $modules = array();

	public static function get_instance() {
		if ( null == self::$instance ) {
			self::$instance = new self;
		}
		// add_action('wp_ajax_mauna_import', array($this,'mauna_import'));
		return self::$instance;
	}

	private function __construct() {
		$this->load_modules();
		$this->mauna_add_import_handler();
	}

	public function mauna_add_import_handler() {
		add_action('wp_ajax_mauna_import', array($this,'mauna_import'));
	}

	public function mauna_import() {
		$mauna_demo_importer = new Demo_Importer();
		$mauna_demo_importer->imagesURL = 'http://mauna.puruno.com/demo1/';

		$folder = "demo1/";
		if (!empty($_POST['demo'])) {
			$folder = $_POST['demo'] . "/";
		}

		if(isset($_POST['type']) && $_POST['type'] == 'content') {
			$mauna_demo_importer->import($folder . 'demo.txt');
			self::mauna_create_dummy_media($folder);
		}
		$mauna_demo_importer->import_redux($folder . 'redux.txt');
		die();
	}

	private function mauna_create_dummy_media($demo) {
		if($demo == 'demo1/') {
			$images = array(
				'http://mauna.puruno.com/images/demo1/wed1.jpeg',
				'http://mauna.puruno.com/images/demo1/wed2.jpeg', 
				'http://mauna.puruno.com/images/demo1/wed3.jpeg',
				'http://mauna.puruno.com/images/demo1/wed4.jpeg',
				'http://mauna.puruno.com/images/demo1/wed5.jpeg'
			);
		} elseif($demo == 'demo2/') {
			$images = array(
				'http://mauna.puruno.com/images/demo2/fot1.jpeg',
				'http://mauna.puruno.com/images/demo2/fot2.jpeg', 
				'http://mauna.puruno.com/images/demo2/fot3.jpeg',
				'http://mauna.puruno.com/images/demo2/fot4.jpeg',
				'http://mauna.puruno.com/images/demo2/fot5.jpeg',
				'http://mauna.puruno.com/images/demo2/fot6.jpeg',
				'http://mauna.puruno.com/images/demo2/fot7.jpeg'
			);
		} elseif($demo == 'demo3/') {
			$images = array(
				'http://mauna.puruno.com/images/demo3/for1.jpeg',
				'http://mauna.puruno.com/images/demo3/for2.jpeg', 
				'http://mauna.puruno.com/images/demo3/for3.jpeg',
				'http://mauna.puruno.com/images/demo3/for4.jpeg',
				'http://mauna.puruno.com/images/demo3/for5.jpeg',
				'http://mauna.puruno.com/images/demo3/for6.jpeg'
			);
		} elseif($demo == 'demo4/') {
			$images = array(
				'http://mauna.puruno.com/images/demo4/tat1.jpeg',
				'http://mauna.puruno.com/images/demo4/tat2.jpeg', 
				'http://mauna.puruno.com/images/demo4/tat3.jpeg',
				'http://mauna.puruno.com/images/demo4/tat4.jpeg',
				'http://mauna.puruno.com/images/demo4/tat5.jpeg',
				'http://mauna.puruno.com/images/demo4/tat6.jpeg'
			);
		} elseif($demo == 'demo5/') {
			$images = array(
				'http://mauna.puruno.com/images/demo5/art1.jpeg',
				'http://mauna.puruno.com/images/demo5/art2.jpeg', 
				'http://mauna.puruno.com/images/demo5/art3.jpeg',
				'http://mauna.puruno.com/images/demo5/art4.jpeg',
				'http://mauna.puruno.com/images/demo5/art5.jpeg'
			);
		} elseif($demo == 'demo6/') {
			$images = array(
				'http://mauna.puruno.com/images/demo6/wom1.jpeg',
				'http://mauna.puruno.com/images/demo6/wom2.jpeg', 
				'http://mauna.puruno.com/images/demo6/wom3.jpeg',
				'http://mauna.puruno.com/images/demo6/wom4.jpeg',
				'http://mauna.puruno.com/images/demo6/wom5.jpeg'
			);
		} elseif($demo == 'demo7/') {
			$images = array(
				'http://mauna.puruno.com/images/demo7/win1.jpeg',
				'http://mauna.puruno.com/images/demo7/win2.jpeg', 
				'http://mauna.puruno.com/images/demo7/win3.jpeg',
				'http://mauna.puruno.com/images/demo7/win4.jpeg',
			);
		} elseif($demo == 'demo8/') {
			$images = array(
				'http://mauna.puruno.com/images/demo8/ban1.jpeg',
				'http://mauna.puruno.com/images/demo8/ban2.jpeg', 
				'http://mauna.puruno.com/images/demo8/ban3.jpeg',
				'http://mauna.puruno.com/images/demo8/ban4.jpeg',
			);			
		} else {
			$images = array(
				'http://mauna.puruno.com/images/demo9/sho1.jpeg',
				'http://mauna.puruno.com/images/demo9/sho2.jpeg', 
				'http://mauna.puruno.com/images/demo9/sho3.jpeg',
			);			
		}

		$imagesIds = array();
		$id = 999;
		foreach($images as $img) {
			$imagesIds[] = self::fetch_media($img, $id);
			$id++;
		}
		
		self::mauna_update_thumbnails_with_dummy($imagesIds);
	}

	private function mauna_update_thumbnails_with_dummy($media) {
		global $wpdb;

		$i = 0;
		$slider = implode(',', $media);
		$wpdb->update('wp_postmeta', array( 'meta_value' => $slider ), array('meta_key'=>'mauna_home_background_images'), array('%s'));
		$wpdb->update('wp_postmeta', array( 'meta_value' => $slider ), array('meta_key'=>'mauna_portfolio_item_gallery'), array('%s'));

		query_posts( array(
	    	'post_type' => array( 'post', 'mauna_about_item', 'mauna_portfolio_item', 'mauna_promotion_item', 'nav_menu_item' ),
	    	'posts_per_page' => -1 )
	    );
		while ( have_posts() ) {
			if(!isset($media[$i])) {
				$i = 0;
			}
			$img = $media[$i];
			the_post(); 
			update_post_meta(get_the_ID(), '_thumbnail_id', $img);
			$i++;
		}
		
		$args = array ( 'posts_per_page' => -1, 'post_type'=>'page');
		$the_query = new WP_Query( $args );

		// The Loop 
		$i = 0;
		$gallery = '';
		
		for ($count=0; $count <= 2; $count++) { 
			if($gallery != '') {
				$gallery .= ',';
			}
			$gallery .= implode(',', $media);
		}
		
		while ( $the_query->have_posts() ) :
			$the_query->the_post();
			if(!isset($media[$i])) {
				$i = 0;
			}
			$img = $media[$i];

			update_post_meta(get_the_ID(), '_thumbnail_id', $img);
			$gallery1 = get_post_meta( get_the_ID()); 
			if(array_key_exists('mauna_portfolio_custom', $gallery1)) {
				update_post_meta(get_the_ID(), 'mauna_portfolio_custom', $gallery);
			}
			$gallery2 = get_post_meta( get_the_ID()); 
			if(array_key_exists('mauna_portfolio2_custom', $gallery2)) {
				update_post_meta(get_the_ID(), 'mauna_portfolio2_custom', $gallery);
			}
			$gallery3 = get_post_meta( get_the_ID()); 
			if(array_key_exists('mauna_portfolio3_custom', $gallery3)) {
				update_post_meta(get_the_ID(), 'mauna_portfolio3_custom', $gallery);
			}
			$gallery4 = get_post_meta( get_the_ID()); 
			if(array_key_exists('mauna_portfolio4_custom', $gallery4)) {
				update_post_meta(get_the_ID(), 'mauna_portfolio4_custom', $gallery);
			}
			$i++;
		endwhile;

	}

	public function load_modules() {
		$this->modules[] = new Mauna_Post_Types;
		$this->modules[] = new Mauna_Shortcodes();
	}
		/* Import media from url
	 *
	 * @param string $file_url URL of the existing file from the original site
	 * @param int $post_id The post ID of the post to which the imported media is to be attached
	 *
	 * @return boolean True on success, false on failure
	 */

	public function fetch_media($file_url, $post_id) {
		require_once(ABSPATH . 'wp-load.php');
		require_once(ABSPATH . 'wp-admin/includes/image.php');
		global $wpdb;

		if(!$post_id) {
			return false;
		}

		//directory to import to	
		$artDir = 'wp-content/uploads/importedmedia/';

		//if the directory doesn't exist, create it	
		if(!file_exists(ABSPATH.$artDir)) {
			mkdir(ABSPATH.$artDir);
		}

		//rename the file... alternatively, you could explode on "/" and keep the original file name
		$ext = array_pop(explode(".", $file_url));
		$new_filename = 'importedmedia-'.$post_id.".".$ext; //if your post has multiple files, you may need to add a random number to the file name to prevent overwrites

		if (@fclose(@fopen($file_url, "r"))) { //make sure the file actually exists
			copy($file_url, ABSPATH.$artDir.$new_filename);

			$siteurl = get_option('siteurl');
			$file_info = getimagesize(ABSPATH.$artDir.$new_filename);

			//create an array of attachment data to insert into wp_posts table
			$artdata = array();
			$artdata = array(
				'post_author' => 1, 
				'post_date' => current_time('mysql'),
				'post_date_gmt' => current_time('mysql'),
				'post_title' => $new_filename, 
				'post_status' => 'inherit',
				'comment_status' => 'closed',
				'ping_status' => 'closed',
				'post_name' => sanitize_title_with_dashes(str_replace("_", "-", $new_filename)),
				'post_modified' => current_time('mysql'),
				'post_modified_gmt' => current_time('mysql'),
				'post_parent' => $post_id,
				'post_type' => 'attachment',
				'guid' => $siteurl.'/'.$artDir.$new_filename,
				'post_mime_type' => $file_info['mime'],
				'post_excerpt' => '',
				'post_content' => ''
			);

			$uploads = wp_upload_dir();
			$save_path = $uploads['basedir'].'/importedmedia/'.$new_filename;

			//insert the database record
			$attach_id = wp_insert_attachment( $artdata, $save_path, $post_id );

			//generate metadata and thumbnails
			if ($attach_data = wp_generate_attachment_metadata( $attach_id, $save_path)) {
				wp_update_attachment_metadata($attach_id, $attach_data);
			}

			//optional make it the featured image of the post it's attached to
			$rows_affected = $wpdb->insert($wpdb->prefix.'postmeta', array('post_id' => $post_id, 'meta_key' => '_thumbnail_id', 'meta_value' => $attach_id));
		}
		else {
			return false;
		}

		return $attach_id;
	}
}

Mauna_Utility_Plugin::get_instance();



