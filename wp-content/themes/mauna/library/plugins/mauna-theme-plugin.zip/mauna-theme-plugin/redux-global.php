<?php
	/**
	 * ReduxFramework Sample Config File
	 * For full documentation, please visit: http://docs.reduxframework.com/
	 */

	if ( ! class_exists( 'Redux' ) ) {
		return;
	}

	// This is your option name where all the Redux data is stored.
	$opt_name = "mauna_redux";
	// This line is only for altering the demo. Can be easily removed.
	$opt_name = apply_filters( 'mauna_redux/opt_name', $opt_name );

	/*
	 *
	 * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
	 *
	 */

	$sampleHTML = '';
	if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
		Redux_Functions::initWpFilesystem();

		global $wp_filesystem;

		$sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
	}

	// Background Patterns Reader
	$sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
	$sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
	$sample_patterns      = array();
	
	if ( is_dir( $sample_patterns_path ) ) {

		if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
			$sample_patterns = array();

			while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

				if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
					$name              = explode( '.', $sample_patterns_file );
					$name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
					$sample_patterns[] = array(
						'alt' => $name,
						'img' => $sample_patterns_url . $sample_patterns_file
					);
				}
			}
		}
	}

	/**
	 * ---> SET ARGUMENTS
	 * All the possible arguments for Redux.
	 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
	 * */

	$theme = wp_get_theme(); // For use with some settings. Not necessary.

	$args = array(
		// TYPICAL -> Change these values as you need/desire
		'opt_name'             => $opt_name,
		// This is where your data is stored in the database and also becomes your global variable name.
		'display_name'         => $theme->get( 'Name' ),
		// Name that appears at the top of your panel
		'display_version'      => $theme->get( 'Version' ),
		// Version that appears at the top of your panel
		'menu_type'            => 'menu',
		//Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
		'allow_sub_menu'       => true,
		// Show the sections below the admin menu item or not
		'menu_title'           => __( 'Theme Settings', 'mauna' ),
		'page_title'           => __( 'Theme Settings', 'mauna' ),
		// You will need to generate a Google API key to use this feature.
		// Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
		'google_api_key'       => '',
		// Set it you want google fonts to update weekly. A google_api_key value is required.
		'google_update_weekly' => false,
		// Must be defined to add google fonts to the typography module
		'async_typography'     => true,
		// Use a asynchronous font on the front end or font string
		//'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
		'admin_bar'            => true,
		// Show the panel pages on the admin bar
		'admin_bar_icon'       => 'dashicons-portfolio',
		// Choose an icon for the admin bar menu
		'admin_bar_priority'   => 50,
		// Choose an priority for the admin bar menu
		'global_variable'      => '',
		// Set a different name for your global variable other than the opt_name
		'dev_mode'             => false,
		// Show the time the page took to load, etc
		'update_notice'        => false,
		// If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
		'customizer'           => false,
		// Enable basic customizer support
		//'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
		//'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

		// OPTIONAL -> Give you extra features
		'page_priority'        => null,
		// Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
		'page_parent'          => 'themes.php',
		// For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
		'page_permissions'     => 'manage_options',
		// Permissions needed to access the options panel.
		'menu_icon'            => '',
		// Specify a custom URL to an icon
		'last_tab'             => '',
		// Force your panel to always open to a specific tab (by id)
		'page_icon'            => 'icon-themes',
		// Icon displayed in the admin panel next to your menu_title
		'page_slug'            => '',
		// Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
		'save_defaults'        => true,
		// On load save the defaults to DB before user clicks save or not
		'default_show'         => false,
		// If true, shows the default value next to each field that is not the default value.
		'default_mark'         => '',
		// What to print by the field's title if the value shown is default. Suggested: *
		'show_import_export'   => true,
		// Shows the Import/Export panel when not used as a field.

		// CAREFUL -> These options are for advanced use only
		'transient_time'       => 60 * MINUTE_IN_SECONDS,
		'output'               => true,
		// Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
		'output_tag'           => true,
		// Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
		'footer_credit'     => ' ',                   // Disable the footer credit of Redux. Please leave if you can help it.

		// FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
		'database'             => '',
		// possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
		'use_cdn'              => true,
		// If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

		// HINTS
		'hints'                => array(
			'icon'          => 'el el-question-sign',
			'icon_position' => 'right',
			'icon_color'    => 'lightgray',
			'icon_size'     => 'normal',
			'tip_style'     => array(
				'color'   => 'red',
				'shadow'  => true,
				'rounded' => false,
				'style'   => '',
			),
			'tip_position'  => array(
				'my' => 'top left',
				'at' => 'bottom right',
			),
			'tip_effect'    => array(
				'show' => array(
					'effect'   => 'slide',
					'duration' => '500',
					'event'    => 'mouseover',
				),
				'hide' => array(
					'effect'   => 'slide',
					'duration' => '500',
					'event'    => 'click mouseleave',
				),
			),
		)
	);

	Redux::setArgs( $opt_name, $args );

	/*
	 *
	 * ---> START SECTIONS
	 *
	 */

	/*

		As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


	 */

	// -> START Basic Fields

	Redux::setSection( $opt_name, array(
		'title'            => __( 'General', 'mauna' ),
		'id'               => 'mauna_general',
		'fields'           => array(
			array(
				'id'       => 'mauna_general_enable_ajax',
				'title' => __( 'Enable ajax transitions between pages', 'mauna' ),
				'subtitle' => __('Disable if you want to use third party plugins', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),

			array(
				'id'       => 'mauna_general_arrow_top',
				'title' => __( 'Show arrow "back to top"', 'mauna' ),
				'subtitle' => __('Enable if you want to show arrow "back to top".', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),

			array(
				'id'       => 'mauna_general_arrow_bg_color',
				'type'     => 'color',
				'default'  => 'rgba(0,0,0,.3)',
				'validate' => '',
				'title'    => __( 'Arrow "back to top" background color', 'mauna' ),
				'output'   => array('background-color' => '#scroll-up'),
				'required' => array( 'mauna_general_arrow_top', '=', true )
			),

			array(
				'id'       => 'mauna_general_arrow_color',
				'type'     => 'color',
				'default'  => '#fff',
				'validate' => '',
				'title'    => __( 'Arrow "back to top" color', 'mauna' ),
				'output'   => array('stroke' => '#scroll-up path'),
				'required' => array( 'mauna_general_arrow_top', '=', true )
			),

			array(
				'id'       => 'mauna_general_page_mask_color',
				'type'     => 'color',
				'default'  => '#111',
				'validate' => '',
				'title'    => __( 'Page transition color', 'mauna' ),
				'output'   => array('background-color' => '.page-mask'),
			),
			 array(
			    'id'   =>'mauna_nav_divider_6',
			    'type' => 'divide'
			),
			array(
		       'id' => 'header-font-start',
		       'type' => 'section',
		       'title' => __('Headers font size', 'mauna'),
		       'indent' => true 
		    ),
		    array(
				'id'       => 'mauna_general_h1_typo',
				'type'        => 'typography', 
				'title'       => __('Header 1 font size', 'mauna'),
				'subtitle' => __( 'Select font size and letter spacing for header 1', 'mauna' ),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('h1, .h1'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => false,
				'text-transform' => false,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'font-family' => false,
				'font-weight' => false,
				'font-style' => false,
				'default'     => array(
					'font-size'	  => '48px',
				),
			),
			array(
				'id'       => 'mauna_general_h2_typo',
				'type'        => 'typography', 
				'title'       => __('Header 2 font size', 'mauna'),
				'subtitle' => __( 'Select font size and letter spacing for header 2', 'mauna' ),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('h2, .h2'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => false,
				'text-transform' => false,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'font-family' => false,
				'font-weight' => false,
				'font-style' => false,
				'default'     => array(
					'font-size'	  => '40px',
				),
			),
			array(
				'id'       => 'mauna_general_h3_typo',
				'type'        => 'typography', 
				'title'       => __('Header 3 font size', 'mauna'),
				'subtitle' => __( 'Select font size and letter spacing for header 3', 'mauna' ),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('h3, .h3'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => false,
				'text-transform' => false,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'font-family' => false,
				'font-weight' => false,
				'font-style' => false,
				'default'     => array(
					'font-size'	  => '31px',
				),
			),
			array(
				'id'       => 'mauna_general_h4_typo',
				'type'        => 'typography', 
				'title'       => __('Header 4 font size', 'mauna'),
				'subtitle' => __( 'Select font size and letter spacing for header 4', 'mauna' ),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('h4, .h4'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => false,
				'text-transform' => false,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'font-family' => false,
				'font-weight' => false,
				'font-style' => false,
				'default'     => array(
					'font-size'	  => '25px',
				),
			),
			array(
				'id'       => 'mauna_general_h5_typo',
				'type'        => 'typography', 
				'title'       => __('Header 5 font size', 'mauna'),
				'subtitle' => __( 'Select font size and letter spacing for header 5', 'mauna' ),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('h5, .h5'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => false,
				'text-transform' => false,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'font-family' => false,
				'font-weight' => false,
				'font-style' => false,
				'default'     => array(
					'font-size'	  => '20px',
				),
			),
			array(
				'id'       => 'mauna_general_h6_typo',
				'type'        => 'typography', 
				'title'       => __('Header 6 font size', 'mauna'),
				'subtitle' => __( 'Select font size and letter spacing for header 6', 'mauna' ),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('h6, .h6'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => false,
				'text-transform' => false,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'font-family' => false,
				'font-weight' => false,
				'font-style' => false,
				'default'     => array(
					'font-size'	  => '16px',
				),
			),
		    array(
		       'id' => 'header-font-end',
		       'type' => 'section',
		       'indent' => false 
		    ),
		    array(
			    'id'   =>'mauna_general_divider_2',
			    'type' => 'divide'
			),
		    array(
		       'id' => 'custom-user-start',
		       'type' => 'section',
		       'title' => __('Custom code', 'mauna'),
		       'indent' => true 
		    ),

			array(
				'id'       	=> 'mauna_custom_user_css',
				'type'     	=> 'ace_editor',
				'title'    	=> __( 'Custom CSS', 'mauna' ),
				'subtitle' 	=> __( 'Enter your custom CSS here', 'mauna' ),
				'mode' 		=> 'css',
				'theme'		=> 'chrome',
				'default'  	=> ''
			),

			array(
				'id' 		=> 'mauna_custom_user_js',
				'type' 		=> 'ace_editor',
				'title' 	=> __( 'Custom JavaScript', 'mauna' ),
				'subtitle' 	=> __( 'Enter your custom JavaScript here', 'mauna' ),
				'mode' 		=> 'javascript',
				'theme' 	=> 'chrome',
				'default' 	=> '',
			),
			array(
		       'id' => 'custom-user-end',
		       'type' => 'section',
		       'indent' => false 
		    ),
			array(
			    'id'   =>'mauna_custom_divider_3',
			    'type' => 'divide'
			),
		)
	));

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Navigation', 'mauna' ),
		'id'               => 'mauna_navigation_settings',
		'icon'             => 'el el-lines',

	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Appearance', 'mauna' ),
		'id'               => 'mauna_nav_appearance',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_header_burger_width',
				'type'     => 'dimensions',
				'units'    => array('px'),
				'title'    => __('Navigation burger width', 'mauna'),
				'height'   => false,
				'output'   => array('.main-navigation .burger-nav'),
				'default'  => array(
					'width'   => '40px',
					'units' => 'px', 
				),
			),
			array(
			   'id' => 'navigation-light-start',
			   'type' => 'section',
			   'title' => __('Light navigation', 'mauna'),
			   // 'subtitle' => __('Select image for large and small logo.', 'mauna'),
			   'indent' => true 
			),
			array(
				'id'       => 'mauna_header_light_logo_large',
				'type'     => 'media',
				'title'    => __( 'Upload large logo', 'mauna' ),
				'subtitle' => __( 'Select image to display as large logo', 'mauna' ),
				'default'  => array(
					'url' => get_template_directory_uri().'/assets/images/light-logo.png',
					'id' => '',
					'height' => '',
					'width' => '',
					'thumbnail' => '',
				),
			),
			array(
				'id'       => 'mauna_header_light_logo_small',
				'type'     => 'media',
				'title'    => __( 'Upload small logo', 'mauna' ),
				'subtitle' => __( 'Select image to display as small logo', 'mauna' ),
				'default'  => array(
					'url' => get_template_directory_uri().'/assets/images/logo-light-small.png',
					'id' => '',
					'height' => '',
					'width' => '',
					'thumbnail' => '',
				),
			),

			array(
				'id'       => 'mauna_header_light_burger_color',
				'type'     => 'color',
				'default'  => 'rgba(255,255,255,1)',
				'validate' => '',
				'title'    => __( 'Navigation items & burger color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for light navigation', 'mauna' ),
				'output'   => array('stroke'=>'.navbar-large-light .burger-nav svg', 'color' => '.navbar-large-light .lang-social-menu li, .navbar-large-light .cart-icon, .default-template-title.light-title h3, .portfolio-single-title.light-title h3', 'fill'=>'.navbar-large-light .cart-icon svg'),
			),
			array(
			   'id' => 'navigation-light-end',
			   'type' => 'section',
			   'indent' => false 
			),
			array(
				'id'   =>'mauna_nav_divider_1',
				'type' => 'divide'
			),
			array(
			   'id' => 'navigation-dark-start',
			   'type' => 'section',
			   'title' => __('Dark navigation', 'mauna'),
			   // 'subtitle' => __('Select image for large and small logo.', 'mauna'),
			   'indent' => true 
			),

			array(
				'id'       => 'mauna_header_dark_logo_large',
				'type'     => 'media',
				'title'    => __( 'Upload large logo', 'mauna' ),
				'subtitle' => __( 'Select image to display as large logo', 'mauna' ),
				'default'  => array(
					'url' => get_template_directory_uri().'/assets/images/dark-logo.png',
					'id' => '',
					'height' => '',
					'width' => '',
					'thumbnail' => '',
				),
			),
			array(
				'id'       => 'mauna_header_dark_logo_small',
				'type'     => 'media',
				'title'    => __( 'Upload small logo', 'mauna' ),
				'subtitle' => __( 'Select image to display as small logo', 'mauna' ),
				'default'  => array(
					'url' => get_template_directory_uri().'/assets/images/logo-dark-small.png',
					'id' => '',
					'height' => '',
					'width' => '',
					'thumbnail' => '',
				),
			),

			array(
				'id'       => 'mauna_header_dark_burger_color',
				'type'     => 'color',
				'default'  => '#111',
				'validate' => '',
				'title'    => __( 'Navigation items & burger color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for dark navigation', 'mauna' ),
				'output'   => array('stroke'=>'.navbar-large-dark .burger-nav svg', 'color' => '.navbar-large-dark .lang-social-menu li, .navbar-large-dark .cart-icon, .default-template-title.dark-title h3, .portfolio-single-title.dark-title h3', 'fill'=>'.navbar-large-dark .cart-icon svg'),
			),
			array(
			   'id' => 'navigation-dark-end',
			   'type' => 'section',
			   'indent' => false 
			),
			 array(
				'id'   =>'mauna_nav_divider_2',
				'type' => 'divide'
			),

			array(
			   'id' => 'navigation-overlay-start',
			   'type' => 'section',
			   'title' => __('Navigation overlay', 'mauna'),
			   // 'subtitle' => __('Select image for large and small logo.', 'mauna'),
			   'indent' => true 
			),

			array(
				'id'       => 'mauna_header_overlay_logo',
				'type'     => 'media',
				'title'    => __( 'Upload logo', 'mauna' ),
				'subtitle' => __( 'Select image to display as logo', 'mauna' ),
				'default'  => array(
					'url' => get_template_directory_uri().'/assets/images/logo-light-small.png',
					'id' => '',
					'height' => '',
					'width' => '',
					'thumbnail' => '',
				),
			),
			array(
				'id'       => 'mauna_colors_nav_overlay',
				'type'     => 'color',
				'title'    => __( 'Overlay color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for navigation overlay', 'mauna' ),
				'default'  => 'rgba(17,17,17,.9)',
				'validate' => '',
				'output'   => array('background'=>'.nav-overlay'),
			),
			array(
				'id'       => 'mauna_colors_nav_overlay_txt',
				'type'     => 'color',
				'title'    => __( 'Navigation items & burger color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for navigation items', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color'=>'.navigation-overlay .navigation-content, .navigation-overlay .navigation-content a','stroke'=>'.navigation-overlay .burger-nav svg'),
			),
			array(
				'id'       => 'mauna_colors_nav_overlay_hover',
				'type'     => 'color',
				'title'    => __( 'Items hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background-color'=>'.navigation-overlay .navigation-content a:before'),
			),
			array(
			   'id' => 'navigation-overlay-end',
			   'type' => 'section',
			   'indent' => false 
			),
			 array(
				'id'   =>'mauna_nav_divider_3',
				'type' => 'divide'
			),

			array(
			   'id' => 'navigation-additional-start',
			   'type' => 'section',
			   'title' => __('Additional top navigation', 'mauna'),
			   // 'subtitle' => __('Select image for large and small logo.', 'mauna'),
			   'indent' => true 
			),
			array(
				'id'       => 'mauna_colors_nav_additional_hover',
				'type'     => 'color',
				'title'    => __( 'Items hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background-color'=>'.lang-social-menu .social-profiles a:after'),
			),
			array(
			   'id' => 'navigation-additional-end',
			   'type' => 'section',
			   'indent' => false 
			),
			 array(
				'id'   =>'mauna_nav_divider_4',
				'type' => 'divide'
			),

		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Navigation bar settings', 'mauna' ),
		'id'               => 'mauna_nav_set',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_nav_show_languages',
				'title' => __( 'Show languages switcher', 'mauna' ),
				'subtitle' => __('Select if all templates should contain langauges switcher.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_navigation_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_nav_overlay_typo',
				'type'        => 'typography', 
				'title'       => __('Navigation overlay & top items', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.navigation-overlay .navigation-content a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'font-size' => '16px'
				),
			),
			array(
				'id'       => 'mauna_nav_top_typo',
				'type'        => 'typography', 
				'title'       => __('Additional top navigation items', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.page-wrapper section > .navbar-top a:not(.site-name)'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'font-size' => '12px'
				),
			),

		)
	) );


	// -> START Basic Fields
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Home', 'mauna' ),
		'id'               => 'mauna_home_page',
		'icon'             => 'el el-home',

	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Home content settings', 'mauna' ),
		'id'               => 'mauna_home_content',
		'subsection'       => true,
		'fields'           => array(

			array(
				'id'       => 'mauna_home_show_title',
				'title' => __( 'Show title', 'mauna' ),
				'subtitle' => __('Select if home page should contain title.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_home_break_line',
				'title' => __( 'Break line in navigation after ', 'mauna' ),
				'subtitle' => __('Type number of elements to be visible in each line. 0 will let the elements to use all possible space.', 'mauna'),
				'type' => 'text',
				'default' => 0,
			),
			array(
				'id'       => 'mauna_home_circle_enable',
				'title' => __( 'Show decoration', 'mauna' ),
				'subtitle' => __('Select if home page should contain decoration element.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),

			array(
				'id'       => 'mauna_home_type_decoration',
				'title' => __( 'Decoration element', 'mauna' ),
				'subtitle' => __('Select type of decoration element.', 'mauna'),
				'type' => 'button_set',
				'options' => array(
					'circle' => __('Circle', 'mauna'),
					'triangle' => __('Triangle', 'mauna'),
					'square' => __('Square', 'mauna'),
					'custom' => __('Custom SVG', 'mauna'),
					
				),
				'default' => 'circle',
				'required' => array( 'mauna_home_circle_enable', '=', true )
			),
			array(
				'id'       => 'mauna_home_type_decoration_custom',
				'title' => __( 'Custom SVG element', 'mauna' ),
				'subtitle' => __('Select SVG element.', 'mauna'),
				'type' => 'media',
				'required' => array( 'mauna_home_type_decoration', '=', 'custom' )
			),
			array(
				'id'       => 'mauna_home_circle_position',
				'type' 	   => 'button_set',
				'title' => __( 'Decoration position', 'mauna' ),
				'subtitle'  => __( 'Define position for decoration element', 'mauna' ),
				'options' => array(
					'circle_left' => __('Left', 'mauna'),
					'circle_center' => __('Center', 'mauna'),
					'circle_right' => __('Right', 'mauna'),
					
				),
				'default' => 'circle_center',
				'required' => array( 'mauna_home_circle_enable', '=', true )
			),
			array(
				'id'       => 'mauna_footer_text',
				'type'     => 'editor',
				'title'    => __( 'Footer content', 'mauna' ),
				'subtitle'    => __( 'Type footer text for home page', 'mauna' ),
				'default'  => '&copy; 2016 MAUNA',
				'args'   => array(
					'teeny'            => true,
					'textarea_rows'    => 1,
					'media_buttons'    => false,
				)
			),
		)
	) );

	
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_home_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_home_headers',
				'type'        => 'typography', 
				'title'       => __('Page title', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.home-header header h1'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'font-size' => '40px',
					// 'letter-spacing' => '1px',
					'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_home_title_letter_spacing',
				'title' => __( 'Title letter spacing (in px).', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '50',
				'required' => array( 'mauna_home_show_title', '=', true )
			),
			array(
				'id'       => 'mauna_home_nav_content',
				'type'        => 'typography', 
				'title'       => __('Navigation in content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.home-nav, .home-nav a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'font-weight' => '700',
					'google'      => true,
					'letter-spacing' => '1px',
					'font-size' => '16px',
				),
			),
			array(
				'id'       => 'mauna_home_footer',
				'type'        => 'typography', 
				'title'       => __('Footer content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.home-footer, .home-footer a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'google'      => true,
					'font-size' => '12px',
					'text-align' => 'left',
				),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_home_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_colors_home',
				'type'     => 'color',
				'title'    => __( 'Home content color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for home page content text', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color'=>'.homepage header h1, .open-off-canvas a, .home-footer .footer-content, .home-footer .footer-content a, .home-nav .nav a', 'background-color' => '.open-off-canvas a:after'),
			),
			array(
				'id'       => 'mauna_colors_home_hover',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for home page hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background'=>'.open-off-canvas a.link-hover:before, .home-nav .nav a:after'),
			),
			array(
				'id'       => 'mauna_colors_home_accent',
				'type'     => 'color',
				'title'    => __( 'Accent color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for home page decoration', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('stroke' => '.homepage .decoration svg'),
			),
			array(
				'id'       => 'mauna_colors_home_progress',
				'type'     => 'color',
				'title'    => __( 'Progressbar color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for home page progressbar', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('background'=>'.vegas-timer-progress'),
			),		
			array(
				'id'       => 'mauna_colors_home_control_bg',
				'type'     => 'color',
				'title'    => __( 'Video controls background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for video controls background', 'mauna' ),
				'default'  => 'rgba(0,0,0,.4)',
				'validate' => '',
				'output'   => array('fill' => '.home-video-controls svg .circle-dark, .home-mobile-video-control svg .circle-dark'),
			),
			array(
				'id'       => 'mauna_colors_home_control_color',
				'type'     => 'color',
				'title'    => __( 'Video controls color & border color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for video controls color & border color', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('stroke'=>'.home-video-controls svg .circle-light, .home-mobile-video-control svg .circle-light', 'fill' => '.home-video-controls svg polygon, .home-mobile-video-control svg polygon'),
			),		
		)
	) );
	
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Off canvas', 'mauna' ),
		'id'               => 'mauna_off_canvas',
		'customizer_width' => '500px',
		'icon'             => 'el el-indent-left',
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Content', 'mauna' ),
		'id'               => 'mauna_off_canvas_content',
		'subsection'       => true,
		'customizer_width' => '450px',
		'fields'           => array(
			array(
				'id'       => 'mauna_off_canvas_enable',
				'title' => __( 'Show off canvas', 'mauna' ),
				'subtitle' => __('Show off canvas in home page.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_off_canvas_logo',
				'type'     => 'media',
				'title'    => __( 'Upload logo', 'mauna' ),
				'subtitle' => __( 'Select image to display as logo', 'mauna' ),
				'default'  => array(
					'url' => get_template_directory_uri().'/assets/images/light-logo.png',
					'id' => '',
					'height' => '',
					'width' => '',
					'thumbnail' => '',
				),
			),
			array(
				'id'       => 'mauna_off_canvas_open',
				'type'     => 'text',
				'title'    => __( 'Open button', 'mauna' ),
				'subtitle'    => __( 'Type open button text for off canvas', 'mauna' ),
				'default'  => __( 'Open', 'mauna' ),
				'required' => array( 'mauna_off_canvas_enable', '=', true )
			),   
			array(
				'id'       => 'mauna_off_canvas_close',
				'type'     => 'text',
				'title'    => __( 'Close button', 'mauna' ),
				'subtitle'    => __( 'Type close button text for off canvas', 'mauna' ),
				'default'  => __( 'Close', 'mauna' ),
				'required' => array( 'mauna_off_canvas_enable', '=', true )
			),      
			array(
				'id'       => 'mauna_off_canvas_text',
				'type'     => 'editor',
				'title'    => __( 'Off canvas content', 'mauna' ),
				'subtitle'    => __( 'Type in content displayed in off canvas', 'mauna' ),
				'default'  => '',
				'args'   => array(
					'media_buttons' => true, 'textarea_rows' => 20, 'teeny' => false, 'tinymce' => array('toolbar1'=> 'bold,italic,strikethrough,bullist,numlist,blockquote,hr,alignleft,aligncenter,alignright,link,unlink,wp_more,spellchecker,wp_fullscreen,wp_adv', 'toolbar2' => 'styleselect,formatselect,underline,alignjustify,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo,wp_help'),
				),
				'required' => array( 'mauna_off_canvas_enable', '=', true )
			),      
			
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_off_canvas_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_off_canvas_headers',
				'type'        => 'typography', 
				'title'       => __('Headers', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.off-canvas-content .content h1, .off-canvas-content .content h2, .off-canvas-content .content h3, .off-canvas-content .content h4, .off-canvas-content .content h5, .off-canvas-content .content h6'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'letter-spacing' => '3px',
				),
			),
			array(
				'id'       => 'mauna_off_canvas_content',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.off-canvas-content .content p, .off-canvas-content .content a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Playfair Display', 
					'font-weight' => '400',
					'google'      => true,
					'letter-spacing' => '1px',
					'font-size' => '18px',
				),
			),
			array(
				'id'       => 'mauna_off_canvas_btn',
				'type'        => 'typography', 
				'title'       => __('Buttons open/close', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.open-off-canvas a, .close-off-canvas a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
				),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_off_canvas_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_colors_off_canvas_bg',
				'type'     => 'color',
				'title'    => __( 'Off canvas background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for off canvas', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color'=>'.off-canvas-overlay'),
			),
			array(
				'id'       => 'mauna_colors_off_canvas',
				'type'     => 'color',
				'title'    => __( 'Off canvas text color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for off canvas content text', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color'=>'.off-canvas-content, .off-canvas-content  a, .close-off-canvas a'),
			),
			array(
				'id'       => 'mauna_colors_off_canvas_hover',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for off canvas hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background-color'=>'.close-off-canvas a.link-hover:before'),
			),
			
		)
	) );

	
	// -> START Basic Fields
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Home 2', 'mauna' ),
		'id'               => 'mauna_home2_page',
		'icon'             => 'el el-home',

	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Home content settings', 'mauna' ),
		'id'               => 'mauna_home2_content',
		'subsection'       => true,
		'fields'           => array(
			
			array(
				'id'       => 'mauna_footer2_text',
				'type'     => 'editor',
				'title'    => __( 'Footer content', 'mauna' ),
				'subtitle'    => __( 'Type footer text for home page', 'mauna' ),
				'default'  => '&copy; 2016 MAUNA',
				'args'   => array(
					'teeny'            => true,
					'textarea_rows'    => 1,
					'media_buttons'    => false,
				)
			),

		)
	) );

	
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_home2_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_home2_nav_content',
				'type'        => 'typography', 
				'title'       => __('Navigation headers', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.homepage2 .home-nav-items .home-nav-item span'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => '',
					'font-family' => 'Playfair Display', 
					'font-weight' => '400',
					'font-style' => 'italic',
					'google'      => true,
					'letter-spacing' => '2px',
					'font-size' => '32px',
				),
			),
			array(
				'id'       => 'mauna_home2_footer',
				'type'        => 'typography', 
				'title'       => __('Footer content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.home2-footer, .home2-footer a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'google'      => true,
					'text-align' => 'left',
					'font-size'	=> '12px',
				),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_home2_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id' => 'mauna_home2_color_bg',
				'type' => 'color',
				'title' => __( 'Background color', 'mauna'),
				'validate' => '',
				'default' => '#111',
				'output' => array('background-color' => '.homepage2')
			),
			array(
				'id' => 'mauna_home2_color_overlay',
				'type' => 'color',
				'title' => __( 'Color overlay', 'mauna'),
				'validate' => '',
				'default' => 'rgba(0,0,0,.5)',
				'output' => array('background-color' => '.homepage2 .home-overlay')
			),
			array(
				'id'       => 'mauna_colors_home2',
				'type'     => 'color',
				'title'    => __( 'Home content color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for home page content text', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color'=>'.homepage2 .home-nav-items .home-nav-item span, .home2-footer .footer-content p, .home2-footer .footer-content a'),
			),
			
			array(
				'id'       => 'mauna_colors_home2_border',
				'type'     => 'color',
				'title'    => __( 'Border color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for home page hover', 'mauna' ),
				'default'  => 'rgba(255,255,255,.1)',
				'validate' => '',
				'output'   => array('border-color'=>'.homepage2 .home-nav-items .home-nav-item > a'),
			),
			array(
				'id' => 'mauna_home2_color_hover',
				'type' => 'color',
				'title' => __( 'Overlay hover color', 'mauna'),
				'validate' => '',
				'default' => '#111',
				'transparent' => false,
				'validate' => '',
				'class' => 'no-alpha',
				'output' => array('background-color' => '.homepage2 .home-nav-items .home-nav-item a:before')
			),
		)
	) );
	

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Default template', 'mauna' ),
		'id'               => 'mauna_page_template',
		'customizer_width' => '500px',
		'icon'             => 'el el-edit',
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_page_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_page_headers',
				'type'        => 'typography', 
				'title'       => __('Headers', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.page-content .content h1, .page-content .content h2, .page-content .content h3, .page-content .content h4, .page-content .content h5, .page-content .content h6, .default-template-intro h3'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'letter-spacing' => '3px',
				),
			),
			array(
				'id'       => 'mauna_page_content_typo',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.page-content .content, .page-content .content p, .page-content .content a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '1px',
					'font-size' => '18px'
				),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_page_colors',
		'subsection'       => true,
		'customizer_width' => '450px',
		'fields'           => array(
			array(
				'id'       => 'mauna_page_header_color',
				'type'     => 'color',
				'title'    => __( 'Header color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template title & content navigation.', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('color'=>'.default-page-template .header-wrapper, .default-page-template .header-wrapper a'),
			),
			array(
				'id'       => 'mauna_page_color_accent',
				'type'     => 'color',
				'title'    => __( 'Accent color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for decoration & menu item hover.', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('stroke' => '.default-page-template .decoration svg'),
			),
			array(
				'id'   =>'mauna_page_divider_1',
				'type' => 'divide'
			),
			
			array(
				'id'       => 'mauna_page_content_color',
				'type'     => 'color',
				'title'    => __( 'Text color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template content.', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('color'=>'.page-content, .page-content-wrapper .page-content a'),
			),
			array(
				'id'       => 'mauna_page_color_hover',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				// 'output'   => array('stroke' => '.default-page-template .decoration svg'),
			),
			array(
				'id'       => 'mauna_page_arrow_bg',
				'type'     => 'color',
				'title'    => __( 'Intro arrow background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for intro arrow background', 'mauna' ),
				'default'  => 'rgba(0,0,0,0.3)',
				'validate' => '',
				'output'   => array('background-color' => '.default-arrow-intro'),
			),	
			array(
				'id'       => 'mauna_page_arrow_color',
				'type'     => 'color',
				'title'    => __( 'Intro arrow color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for intro arrow', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('stroke' => '.default-arrow-intro svg'),
			),	
		)
	) );
	
	// -> START Basic Fields
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Horizontal split template', 'mauna' ),
		'id'               => 'mauna_default_template',
		'customizer_width' => '500px',
		'icon'             => 'el el-edit',
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_default_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_default_headers_title',
				'type'        => 'typography', 
				'title'       => __('Header title', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.default-header header h3'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'font-size' => '30px',
					'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_default_headers',
				'type'        => 'typography', 
				'title'       => __('Headers', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.default-content .content h1, .default-content .content h2, .default-content .content h3, .default-content .content h4, .default-content .content h5, .default-content .content h6'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'letter-spacing' => '3px',
				),
			),
			array(
				'id'       => 'mauna_default_content_typo',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.default-content .content p, .default-content .content a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'font-size' => '18px',
					'google'      => true,
					'letter-spacing' => '1px',
				),
			),
			array(
				'id'       => 'mauna_default_nav_typo',
				'type'        => 'typography', 
				'title'       => __('Navigation in content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.default-header .menu-default .menu-item a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
					'font-size' => '16px',
				),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_default_colors',
		'subsection'       => true,
		'customizer_width' => '450px',
		'fields'           => array(
			array(
				'id'       => 'mauna_default_overlay_color',
				'type'     => 'color',
				'title'    => __( 'Overlay color for background image', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for overlay.', 'mauna' ),
				'default'  => 'rgba(0,0,0,.5)',
				'validate' => '',
				'output'   => array('background-color'=>'.default-template .section-overlay'),
			),
			array(
				'id'       => 'mauna_default_header_color',
				'type'     => 'color',
				'title'    => __( 'Header color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template title & content navigation.', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color'=>'.default-template .header-wrapper, .default-template .header-wrapper a'),
			),
			array(
				'id'       => 'mauna_default_color_accent',
				'type'     => 'color',
				'title'    => __( 'Accent color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for decoration & menu item hover.', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('stroke' => '.default-template .decoration svg'),
			),
			array(
				'id'   =>'mauna_default_divider_1',
				'type' => 'divide'
			),
			array(
				'id'       => 'mauna_default_overlay_content_color',
				'type'     => 'color',
				'title'    => __( 'Overlay color for content', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for overlay.', 'mauna' ),
				'default'  => 'rgba(0,0,0,.5)',
				'validate' => '',
				'output'   => array('background-color'=>'.default-content-wrapper'),
			),
			
			array(
				'id'       => 'mauna_default_content_color',
				'type'     => 'color',
				'title'    => __( 'Text color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template content.', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color'=>'.default-content, .default-content a'),
			),
			array(
				'id'       => 'mauna_default_color_hover',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				// 'output'   => array('stroke' => '.default-template .decoration svg'),
			),
		)
	) );

	// -> START Basic Fields
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Vertical split template', 'mauna' ),
		'id'               => 'mauna_default2_template',
		'customizer_width' => '500px',
		'icon'             => 'el el-edit',
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_default2_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_default2_headers_title',
				'type'        => 'typography', 
				'title'       => __('Header title', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.default-header-2 header h3'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'font-size' => '30px',
					'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_default2_headers',
				'type'        => 'typography', 
				'title'       => __('Headers', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.default-content-2 .content h1, .default-content-2 .content h2, .default-content-2 .content h3, .default-content-2 .content h4, .default-content-2 .content h5, .default-content-2 .content h6'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'letter-spacing' => '3px',
				),
			),
			array(
				'id'       => 'mauna_default2_content_typo',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.default-content-2 .content p, .default-content-2 .content a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '1px',
					'font-size' => '18px'
				),
			),
			array(
				'id'       => 'mauna_default2_nav_typo',
				'type'        => 'typography', 
				'title'       => __('Navigation in content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.default-header-2 .menu-default .menu-item a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
					'font-size' => '16px',
				),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_default2_colors',
		'subsection'       => true,
		'customizer_width' => '450px',
		'fields'           => array(
			array(
				'id'       => 'mauna_default2_overlay_color',
				'type'     => 'color',
				'title'    => __( 'Overlay color for background image', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for overlay.', 'mauna' ),
				'default'  => 'rgba(0,0,0,.5)',
				'validate' => '',
				'output'   => array('background-color'=>'.default-template2 .half-overlay, .default-template2 .bg-img:after'),
			),

			array(
				'id'       => 'mauna_default2_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for background content.', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('background-color'=>'.default-template2 .bg-content, .default-template2 .bg-content-overlay'),
			),
			array(
				'id'       => 'mauna_default2_content_color',
				'type'     => 'color',
				'title'    => __( 'Text color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template content.', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('color'=>'.default-content-2, .default-content-2 a'),
			),
			array(
				'id'       => 'mauna_default2_color_hover',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				// 'output'   => array('stroke' => '.default-template .decoration svg'),
			),
		)
	) );

	// -> START Basic Fields
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Blog', 'mauna' ),
		'id'               => 'mauna_blog',
		'icon'             => 'el el-pencil',

	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Blog content settings', 'mauna' ),
		'id'               => 'mauna_blog_posts',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_blog_posts_per_page',
				'type'     => 'text',
				'title'    => __( 'Posts per page', 'mauna' ),
				'subtitle' => __( 'Type how many posts will be shown in gallery. Any posts after this number will be available after clicking "Load more"', 'mauna' ),
				'default' => '6',
			),
			array(
				'id' => 'mauna_blog_date',
				'title' => __( 'Post date', 'mauna' ),
				'subtitle' => __('Select if post in blog list should contain date.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_blog_show_cat',
				'title' => __( 'Post categories', 'mauna' ),
				'subtitle' => __('Select if post in blog list should contain categories.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_blog_footer_text',
				'type'     => 'editor',
				'title'    => __( 'Footer content', 'mauna' ),
				'subtitle'    => __( 'Type footer text for home page', 'mauna' ),
				'default'  => '&copy; 2016 MAUNA',
				'args'   => array(
					'teeny'            => true,
					'textarea_rows'    => 1,
					'media_buttons'    => false,
				)
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Single post settings', 'mauna' ),
		'id'               => 'mauna_blog_post',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id' => 'mauna_post_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-dark',
			),
			array(
				'id' => 'mauna_post_date',
				'title' => __( 'Post date', 'mauna' ),
				'subtitle' => __('Select if single post should contain date.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_post_show_cat',
				'title' => __( 'Post categories', 'mauna' ),
				'subtitle' => __('Select if single post should contain categories.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_post_tag',
				'title' => __( 'Post tags', 'mauna' ),
				'subtitle' => __('Select if single post should contain tags.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_post_show_shares',
				'title' => __( 'Post social shares', 'mauna' ),
				'subtitle' => __('Select if single post should contain social shares.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_social_share_services',
				'type'     => 'checkbox',
				'title'    => __('Enable share to', 'mauna'), 
				'required' => array('mauna_post_show_shares', '=', '1'),
				'options'  => array(
					'facebook' => 'Facebook',
					'twitter' => 'Twitter',
					'google' => 'Google+',
					'tumblr' => 'Tumblr',
					'pinterest' => 'Pinterest'
				),
				'default' => array(
					'facebook' => '1',
					'twitter' => '1',
					'google' => '1',
					'tumblr' => '1',
					'pinterest' => '1'
				)
			),
			array(
				'id'       => 'mauna_post_show_related',
				'title'    => __( "Related post" , 'mauna'),
				'subtitle' => __('Select if single post should contain related post.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_post_show_related_type',
				'type' 	   => 'button_set',
				'title' => __( 'Related by', 'mauna' ),
				'subtitle'  => __( 'Define if post are related by categories or tags', 'mauna' ),
				'options' => array(
					'categories' => __('Categories', 'mauna'),
					'tags' => __('Tags', 'mauna'),
					
				),
				'default' => 'categories',
				'required' => array( 'mauna_post_show_related', '=', true )
			),
			array(
				'id'       => 'mauna_blog_circle_enable',
				'title' => __( 'Show decoration', 'mauna' ),
				'subtitle' => __('Select if home page should contain decoration element.', 'mauna'),
				'type' => 'switch',
				'default' => true,
				'required' => array( 'mauna_post_show_related', '=', true )
			),
			array(
				'id'       => 'mauna_blog_type_decoration',
				'title' => __( 'Decoration element', 'mauna' ),
				'subtitle' => __('Select type of decoration element.', 'mauna'),
				'type' => 'button_set',
				'options' => array(
					'circle' => __('Circle', 'mauna'),
					'triangle' => __('Triangle', 'mauna'),
					'square' => __('Square', 'mauna'),
					'custom' => __('Custom SVG', 'mauna'),
					
				),
				'default' => 'circle',
				'required' => array( 
					array('mauna_blog_circle_enable', '=', true ),
					array( 'mauna_post_show_related', '=', true ),
				)
			),
			array(
				'id'       => 'mauna_blog_type_decoration_custom',
				'title' => __( 'Custom SVG element', 'mauna' ),
				'subtitle' => __('Select SVG element.', 'mauna'),
				'type' => 'media',
				'required' => array( 'mauna_blog_type_decoration', '=', 'custom' )
			),
			array(
				'id'       => 'mauna_blog_circle_position',
				'type' 	   => 'button_set',
				'title' => __( 'Decoration position', 'mauna' ),
				'subtitle'  => __( 'Define position for decoration element', 'mauna' ),
				'options' => array(
					'circle_left' => __('Left', 'mauna'),
					'circle_center' => __('Center', 'mauna'),
					'circle_right' => __('Right', 'mauna'),
					
				),
				'default' => 'circle_center',
				'required' => array( 'mauna_blog_circle_enable', '=', true )
			),
		),

	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_blog_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_blog_headers_typo',
				'type'        => 'typography', 
				'title'       => __('Headers', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.blog-content .post-content header h5, .archive-header h3, .blog-content .post-content header h5 a, .post-comments h6'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'text-align' => 'center',
					'font-size' => '20px',
				),
			),
			array(
				'id'       => 'mauna_blog_content_typo',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.blog-content .post-content .content, .blog-content .post-content a, .blog-content .post-content .more-link, .blog-content .post-meta a, .blog-content .post-date, .post-comments .comment-date, .post-comments .comment-logged-in, .blog-content .share-header, .blog-content .shares a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'font-weight' => '',
					'google'      => true,
					'letter-spacing' => '',
					'font-size' => '18px',
				),
			),
			array(
				'id'       => 'mauna_blog_post_meta_typo',
				'type'        => 'typography', 
				'title'       => __('Post meta', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.blog-content .post-meta a, .blog-content .post-date'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'font-weight' => '400',
					'font-style' => 'italic',
					'google'      => true,
					'letter-spacing' => '',
					'font-size' => '14px',
				),
			),
			array(
				'id'       => 'mauna_blog_footer_typo',
				'type'        => 'typography', 
				'title'       => __('Footer content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.blog-footer .footer-content a, .blog-footer .footer-content'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '',
					'text-align' => 'center',
					'font-size' => '12px'
				),
			),
			array(
				'id'       => 'mauna_blog_comment_typo',
				'type'        => 'typography', 
				'title'       => __('Comments content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.post-comments .comment-author-link a, .post-comments .comment-author-link, .post-comments .comment p, .post-comments .comment a, .post-comments #respond h6, .post-comments .comment-submit .btn, .post-comments .comment-form-input, .post-comments .numeric-pagination, .post-comments .numeric-pagination a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => '',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'letter-spacing' => '',
					'font-size' => '14px',
				),
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_blog_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_blog_bg_color',
				'type'     => 'color',
				'title'    => __( 'Blog background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for blog/single post background.', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('background-color'=>'.blog, .blog-footer'),
			),
			array(
				'id'       => 'mauna_blog_color',
				'type'     => 'color',
				'title'    => __( 'Blog text color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for blog/single post text.', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('color'=>'.blog, .blog-footer .footer-content, .blog-footer .footer-content a, .blog a', 'background-color' => '.blog-content .more-link span:after, .post-comments .numeric-pagination .current:after'),
			),
			array(
				'id'       => 'mauna_blog_hover_color',
				'type'     => 'color',
				'title'    => __( 'Accent & hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for blog/single post hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background'=>'.blog .post-tags a:after, .blog .link-hover:before, .blog .post-share a:before', 'stroke' => '.blog .decoration svg'),
			),
			array(
				'id'       => 'mauna_blog_hover_img_color',
				'type'     => 'color',
				'title'    => __( 'Image hover color', 'mauna' ),
				'subtitle' => __( 'Select color for image hover', 'mauna' ),
				'default'  => '#000',
				'validate' => '',
				'transparent' => false,
				'class' => 'no-alpha',
				'output'   => array('background'=>'.blog-content .post-image figure >a:before, .blog-content .post-image figure >a:after, #single-post .gallery-item a:before, #single-post .gallery-item a:after'),
			),	
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'About template', 'mauna' ),
		'id'               => 'mauna_about',
		'customizer_width' => '500px',
		'icon'             => 'el el-adult',
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Slider settings', 'mauna' ),
		'id'               => 'mauna_about_settings',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_about_slug',
				'title' => __( 'Single about slug ', 'mauna' ),
				'subtitle' => __('Type unique slug that will be used with permalinks', 'mauna'),
				'type' => 'text',
				'default' => '',
			),
			array(
				'id' => 'mauna_about_arrow',
				'title' => __( 'Arrow next slide', 'mauna' ),
				'subtitle' => __('Select if about template should contain arrow.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_about_pagination',
				'title' => __( 'Pagination', 'mauna' ),
				'subtitle' => __('Select if about template should contain pagination.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Overlay settings', 'mauna' ),
		'id'               => 'mauna_about_overlay',
		'subsection'       => true,
		'fields'           => array(
			// array(
			// 	'id' => 'mauna_about_open_overlay',
			// 	'title' => __( 'Overlay content', 'mauna' ),
			// 	'subtitle' => __('Select if overlay should open at start.', 'mauna'),
			// 	'type' => 'switch',
			// 	'default' => true,
			// ),
			array(
				'id'       => 'mauna_about_open',
				'type'     => 'text',
				'title'    => __( 'Open button', 'mauna' ),
				'subtitle'    => __( 'Type open button text for about overlay', 'mauna' ),
				'default'  => __( 'Show content', 'mauna' ),
			),   
			array(
				'id'       => 'mauna_about_close',
				'type'     => 'text',
				'title'    => __( 'Close button', 'mauna' ),
				'subtitle'    => __( 'Type close button text for about overlay', 'mauna' ),
				'default'  => __( 'Picture only', 'mauna' ),
			),      
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_about_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_about_headers',
				'type'        => 'typography', 
				'title'       => __('Headers', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.about-content-wrapper header h3'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'font-size' => '30px', 
					'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_about_content',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.about-content, .about-content a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => '',
					'font-family' => 'Lato', 
					'font-weight' => '',
					'google'      => true,
					'letter-spacing' => '1px',
					'font-size' => '16px',
				),
			),
			array(
				'id'       => 'mauna_about_elements',
				'type'        => 'typography', 
				'title'       => __('Buttons "open/close" & pagination', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.about-sections .close-content-section a, .about-sections .open-content-section a, #fp-nav li:before'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'font-weight' => '700',
					'letter-spacing' => '2px',
				),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Portfolio rows', 'mauna' ),
		'id'               => 'mauna_portfolio',
		'customizer_width' => '500px',
		'icon'             => 'el el-picture',
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Content settings', 'mauna' ),
		'id'               => 'mauna_portfolio_settings',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id' => 'mauna_portfolio_arrow',
				'title' => __( 'Slider arrows', 'mauna' ),
				'subtitle' => __('Select if portfolio template should contain arrows.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_portfolio_caption',
				'title' => __( 'Image caption', 'mauna' ),
				'subtitle' => __('Select if portfolio lightbox should contain image caption.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),

			// array(
			// 	'id' => 'mauna_portfolio_lightbox_open',
			// 	'title' => __( 'Portfolio gallery', 'mauna' ),
			// 	'subtitle' => __('Action after click in photo.', 'mauna'),
			// 	'type' => 'button_set',
			// 	'options' => array(
			// 		'action' => __('Open portfolio gallery', 'mauna'),
			// 		'nothing' => __('Do nothing', 'mauna'),					
			// 	),
			// 	'default' => 'action'
			// ),
			array(
				'id' => 'mauna_portfolio_title_hover',
				'title' => __( 'Show single portfolio title', 'mauna' ),
				'subtitle' => __('Select if portfolio should contain single portfolio title on hover', 'mauna'),
				'type' => 'switch',
				'default' => true,
				'required' => array( 'mauna_portfolio_lightbox_open', '=', 'action' )
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_portfolio_typo',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio_caption_typo',
				'type'        => 'typography', 
				'title'       => __('Image caption', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio .portfolio-filters .img-caption'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => '',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'font-weight' => '400',
					'font-style' => 'italic',
				),
			),
			array(
				'id'       => 'mauna_portfolio_filters_typo',
				'type'        => 'typography', 
				'title'       => __('Filter list', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio .portfolio-filters ul a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
				),
			),
			array(
				'id'       => 'mauna_portfolio_title_hover_typo',
				'type'        => 'typography', 
				'title'       => __('Single portfolio title on hover', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio .portfolio-hover-title'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
					'font-size' => '20px',
				),
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_portfolio_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio, .portfolio .overlay-hover-title:after'),
			),	
			// array(
			// 	'id'       => 'mauna_portfolio_hover_color',
			// 	'type'     => 'color',
			// 	'title'    => __( 'Accent & hover color', 'mauna' ),
			// 	'subtitle' => __( 'Select color and opacity for portfolio page hover', 'mauna' ),
			// 	'default'  => '#55DAA5',
			// 	'validate' => '',
			// 	'output'   => array('stroke' => '.portfolio .arrow-hover line, .portfolio .portfolio-arrow:hover svg'),
			// ),	
			array(
				'id'       => 'mauna_portfolio_arrow_bg_color',
				'type'     => 'color',
				'title'    => __( 'Button "prev/next slide" background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for button background', 'mauna' ),
				'default'  => 'rgba(0,0,0,0.3)',
				'validate' => '',
				'output'   => array('background-color'=>'.portfolio .portfolio-arrow', 'fill' => '.portfolio .portfolio-video-control svg .circle-dark'),
			),		
			array(
				'id'       => 'mauna_portfolio_arrow_color',
				'type'     => 'color',
				'title'    => __( 'Button "prev/next slide" color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio page hover', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('stroke' => '.portfolio .portfolio-arrow svg', 'color' => '.portfolio .portfolio-hover-title', 'fill' => '.portfolio .portfolio-video-control svg polygon'),
			),
			array(
				'id'       => 'mauna_portfolio_progress',
				'type'     => 'color',
				'title'    => __( 'Progress bar color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for progress bar', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio .swiper-pagination .swiper-pagination-progressbar'),
			),
			array(
				'id'       => 'mauna_portfolio_filters_bg',
				'type'     => 'color',
				'title'    => __( 'Filter list background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio .portfolio-filters'),
			),	
			array(
				'id'       => 'mauna_portfolio_filters',
				'type'     => 'color',
				'title'    => __( 'Filter list color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color' => '.portfolio .portfolio-filters, .portfolio .portfolio-filters a'),
			),	
			array(
				'id'       => 'mauna_portfolio_filters_hover',
				'type'     => 'color',
				'title'    => __( 'Filter hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array(),
			),	
		)
	) );
	
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Portfolio full slider', 'mauna' ),
		'id'               => 'mauna_portfolio2',
		'customizer_width' => '500px',
		'icon'             => 'el el-picture',
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Content settings', 'mauna' ),
		'id'               => 'mauna_portfolio2_settings',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id' => 'mauna_portfolio2_arrow',
				'title' => __( 'Slider arrows', 'mauna' ),
				'subtitle' => __('Select if portfolio template should contain arrows.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_portfolio2_caption',
				'title' => __( 'Image caption', 'mauna' ),
				'subtitle' => __('Select if portfolio should contain image caption.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			// array(
			// 	'id' => 'mauna_portfolio2_lightbox_open',
			// 	'title' => __( 'Portfolio gallery', 'mauna' ),
			// 	'subtitle' => __('Action after click in photo.', 'mauna'),
			// 	'type' => 'button_set',
			// 	'options' => array(
			// 		'action' => __('Open portfolio gallery', 'mauna'),
			// 		'nothing' => __('Do nothing', 'mauna'),					
			// 	),
			// 	'default' => 'action'
			// ),
			// array(
			// 	'id' => 'mauna_about_pagination',
			// 	'title' => __( 'Pagination', 'mauna' ),
			// 	'subtitle' => __('Select if about template should contain pagination.', 'mauna'),
			// 	'type' => 'switch',
			// 	'default' => true,
			// ),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_portfolio2_typo',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio2_caption_typo',
				'type'        => 'typography', 
				'title'       => __('Image caption', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio2 .portfolio2-filters .img-caption'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => '',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'font-weight' => '400',
					'font-style' => 'italic',
				),
			),
			array(
				'id'       => 'mauna_portfolio2_filters_typo',
				'type'        => 'typography', 
				'title'       => __('Filter list', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio2 .portfolio2-filters ul a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
				),
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_portfolio2_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio2_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio2'),
			),	
			// array(
			// 	'id'       => 'mauna_portfolio_hover_color',
			// 	'type'     => 'color',
			// 	'title'    => __( 'Accent & hover color', 'mauna' ),
			// 	'subtitle' => __( 'Select color and opacity for portfolio page hover', 'mauna' ),
			// 	'default'  => '#55DAA5',
			// 	'validate' => '',
			// 	'output'   => array('stroke' => '.portfolio .arrow-hover line, .portfolio .portfolio-arrow:hover svg'),
			// ),	
			array(
				'id'       => 'mauna_portfolio2_arrow_bg_color',
				'type'     => 'color',
				'title'    => __( 'Button "prev/next slide" background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for button background', 'mauna' ),
				'default'  => 'rgba(0,0,0,0.3)',
				'validate' => '',
				'output'   => array('background-color'=>'.portfolio2 .portfolio-arrow', 'fill' => '.portfolio2 .portfolio-video-control svg .circle-dark'),
			),		
			array(
				'id'       => 'mauna_portfolio2_arrow_color',
				'type'     => 'color',
				'title'    => __( 'Button "prev/next slide" color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio page hover', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('stroke' => '.portfolio2 .portfolio-arrow svg', 'fill' => '.portfolio2 .portfolio-video-control svg polygon'),
			),	
			array(
				'id'       => 'mauna_portfolio2_progress',
				'type'     => 'color',
				'title'    => __( 'Progress bar color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for progress bar', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio2 .swiper-pagination .swiper-pagination-progressbar'),
			),
			array(
				'id'       => 'mauna_portfolio2_filters_bg',
				'type'     => 'color',
				'title'    => __( 'Filter list background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio2 .portfolio2-filters'),
			),	
			array(
				'id'       => 'mauna_portfolio2_filters',
				'type'     => 'color',
				'title'    => __( 'Filter list color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color' => '.portfolio2 .portfolio2-filters, .portfolio2 .portfolio2-filters a'),
			),	
			array(
				'id'       => 'mauna_portfolio2_filters_hover',
				'type'     => 'color',
				'title'    => __( 'Filter hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array(),
			),	
		)
	) );
	
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Portfolio masonry', 'mauna' ),
		'id'               => 'mauna_portfolio3',
		'customizer_width' => '500px',
		'icon'             => 'el el-picture',
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Content settings', 'mauna' ),
		'id'               => 'mauna_portfolio3_settings',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id' => 'mauna_portfolio3_caption',
				'title' => __( 'Image caption', 'mauna' ),
				'subtitle' => __('Select if portfolio should contain image caption.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			// array(
			// 	'id' => 'mauna_portfolio3_lightbox_open',
			// 	'title' => __( 'Portfolio gallery', 'mauna' ),
			// 	'subtitle' => __('Action after click in photo.', 'mauna'),
			// 	'type' => 'button_set',
			// 	'options' => array(
			// 		'action' => __('Open portfolio gallery', 'mauna'),
			// 		'nothing' => __('Do nothing', 'mauna'),					
			// 	),
			// 	'default' => 'action'
			// ),
			array(
				'id' => 'mauna_portfolio3_title_hover',
				'title' => __( 'Show single portfolio title', 'mauna' ),
				'subtitle' => __('Select if portfolio should contain single portfolio title on hover', 'mauna'),
				'type' => 'switch',
				'default' => true,
				'required' => array( 'mauna_portfolio3_lightbox_open', '=', 'action' )
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_portfolio3_typo',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio3_btn_typo',
				'type'        => 'typography', 
				'title'       => __('Button "load more"', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio3 .portfolio-load-more-wrapper a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'font-weight' => '700',
					'letter-spacing' => '5px',
				),
			),
			array(
				'id'       => 'mauna_portfolio3_filters_typo',
				'type'        => 'typography', 
				'title'       => __('Filter list', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio3 .portfolio3-filters ul a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
					// 'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_portfolio3_title_hover_typo',
				'type'        => 'typography', 
				'title'       => __('Single portfolio title on hover', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio3 .portfolio-hover-title'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
					'font-size' => '20px',
					// 'text-align' => 'center',
				),
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_portfolio3_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio3_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio3, .portfolio3 .page-bg, .portfolio3 .img-bg-2:after', 'fill' => '.portfolio3 .portfolio-video-control svg .circle-dark'),
			),
		
			array(
				'id'       => 'mauna_portfolio3_btn',
				'type'     => 'color',
				'title'    => __( 'Button "load more" color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for button "load more"', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color' => '.portfolio3 .portfolio-load-more-wrapper a, .portfolio3 .portfolio-hover-title', 'fill' => '.portfolio3 .portfolio-video-control svg polygon'),
			),
			array(
				'id'       => 'mauna_portfolio3_filters_bg',
				'type'     => 'color',
				'title'    => __( 'Filter list background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio3 .portfolio3-filters'),
			),	
			array(
				'id'       => 'mauna_portfolio3_filters',
				'type'     => 'color',
				'title'    => __( 'Filter list color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color' => '.portfolio3 .portfolio3-filters, .portfolio3 .portfolio3-filters a'),
			),	
			array(
				'id'       => 'mauna_portfolio3_hover',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters & button "load more"', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio3 .link-hover:before'),
			),	
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Portfolio grid', 'mauna' ),
		'id'               => 'mauna_portfolio4',
		'customizer_width' => '500px',
		'icon'             => 'el el-picture',
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Content settings', 'mauna' ),
		'id'               => 'mauna_portfolio4_settings',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id' => 'mauna_portfolio4_caption',
				'title' => __( 'Image caption', 'mauna' ),
				'subtitle' => __('Select if portfolio should contain image caption.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			// array(
			// 	'id' => 'mauna_portfolio4_lightbox_open',
			// 	'title' => __( 'Portfolio gallery', 'mauna' ),
			// 	'subtitle' => __('Action after click in photo.', 'mauna'),
			// 	'type' => 'button_set',
			// 	'options' => array(
			// 		'action' => __('Open portfolio gallery', 'mauna'),
			// 		'nothing' => __('Do nothing', 'mauna'),					
			// 	),
			// 	'default' => 'action'
			// ),
			array(
				'id' => 'mauna_portfolio4_title_hover',
				'title' => __( 'Show single portfolio title', 'mauna' ),
				'subtitle' => __('Select if portfolio should contain single portfolio title on hover', 'mauna'),
				'type' => 'switch',
				'default' => true,
				'required' => array( 'mauna_portfolio4_lightbox_open', '=', 'action' )
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_portfolio4_typo',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio4_btn_typo',
				'type'        => 'typography', 
				'title'       => __('Button "load more"', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio4 .portfolio-load-more-wrapper a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'font-weight' => '700',
					'letter-spacing' => '5px',
					// 'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_portfolio4_filters_typo',
				'type'        => 'typography', 
				'title'       => __('Filter list', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio4 .portfolio4-filters ul a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
					// 'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_portfolio4_title_hover_typo',
				'type'        => 'typography', 
				'title'       => __('Single portfolio title on hover', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio4 .portfolio-hover-title'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
					'font-size' => '20px',
					// 'text-align' => 'center',
				),
			),
		)
	) );


	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_portfolio4_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio4_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio4, .portfolio4 .page-bg, .portfolio4 .img-bg-2:after', 'fill' => '.portfolio4 .portfolio-video-control svg .circle-dark'),
			),
		
			array(
				'id'       => 'mauna_portfolio4_btn',
				'type'     => 'color',
				'title'    => __( 'Button "load more" color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for button "load more"', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color' => '.portfolio4 .portfolio-load-more-wrapper a, .portfolio-hover-title', 'fill' => '.portfolio4 .portfolio-video-control svg polygon'),
			),
			array(
				'id'       => 'mauna_portfolio4_filters_bg',
				'type'     => 'color',
				'title'    => __( 'Filter list background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio4 .portfolio4-filters'),
			),	
			array(
				'id'       => 'mauna_portfolio4_filters',
				'type'     => 'color',
				'title'    => __( 'Filter list color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color' => '.portfolio4 .portfolio4-filters, .portfolio4 .portfolio4-filters a'),
			),	
			array(
				'id'       => 'mauna_portfolio4_hover',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for portfolio filters & button "load more"', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio4 .link-hover:before'),
			),	
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Single portfolio', 'mauna' ),
		'id'               => 'mauna_single_portfolio',
		'customizer_width' => '500px',
		'icon'             => 'el el-picture',
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Content settings', 'mauna' ),
		'id'               => 'mauna_single_portfolio_settings',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio_single_slug',
				'title' => __( 'Single portfolio slug ', 'mauna' ),
				'subtitle' => __('Type unique slug that will be used with permalinks', 'mauna'),
				'type' => 'text',
				'default' => '',
			),
			array(
				'id' => 'mauna_portfolio_single_lightbox_open',
				'title' => __( 'Single portfolio lightbox', 'mauna' ),
				'subtitle' => __('Open lightbox after click in photo.', 'mauna'),
				'type' => 'switch',
				'default' => true
			),
			array(
				'id' => 'mauna_portfolio_single_show_shares',
				'title' => __( 'Single portfolio social shares', 'mauna' ),
				'subtitle' => __('Select if single portfolio should contain social shares.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
		),
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_portfolio_single_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio_single_title_typo',
				'type'        => 'typography', 
				'title'       => __('Post title', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio-post-content header h3, .portfolio-single-intro .portfolio-single-title h3'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'font-size' => '30px',
					'letter-spacing' => '3px',
					'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_portfolio_single_content_typo',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.portfolio-post-content .content, .portfolio-post-content .content a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'font-size' => '18px',
					'google'      => true,
					'letter-spacing' => '1px',
					// 'text-align' => 'left',
				),
			),
		)
	) );
   	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_portfolio_single_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_portfolio_single_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for background', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio-single-post, .portfolio-single-post .blog-footer'),
			),	
			array(
				'id'       => 'mauna_portfolio_single_header_color',
				'type'     => 'color',
				'title'    => __( 'Post title color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for single portfolio title .', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('color' => '.portfolio-post-content header h3'),
			),	
			array(
				'id'       => 'mauna_portfolio_single_content_color',
				'type'     => 'color',
				'title'    => __( 'Content color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for single portfolio content', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('color' => '.portfolio-post-content .content, .portfolio-post-content .content a'),
			),	

			array(
				'id'       => 'mauna_portfolio_single_hover_post',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for single portfolio hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background' => '.portfolio-post-content a:hover, .portfolio-post-content .link-hover:before, .portfolio-post-content .post-share a:before'),
			),	
			array(
				'id'       => 'mauna_portfolio_single_hover_img',
				'type'     => 'color',
				'title'    => __( 'Image hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for image hover', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background'=>'.gallery-single-portfolio .post-image >a:before, .gallery-single-portfolio .post-image >a:after'),
			),	
			array(
				'id'       => 'mauna_portfolio_single_arrow_bg',
				'type'     => 'color',
				'title'    => __( 'Intro arrow background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for intro arrow background', 'mauna' ),
				'default'  => 'rgba(0,0,0,0.3)',
				'validate' => '',
				'output'   => array('background-color' => '.portfolio-arrow-intro'),
			),	
			array(
				'id'       => 'mauna_portfolio_single_arrow_color',
				'type'     => 'color',
				'title'    => __( 'Intro arrow color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for intro arrow', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('stroke' => '.portfolio-arrow-intro svg'),
			),	
		)
	) );


	Redux::setSection( $opt_name, array(
		'title'            => __( 'Announcements template', 'mauna' ),
		'id'               => 'mauna_promotion',
		'customizer_width' => '500px',
		'icon'             => 'el el-tag',
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Content settings', 'mauna' ),
		'id'               => 'mauna_promotion_settings',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_promotion_single_slug',
				'title' => __( 'Single annoucement slug ', 'mauna' ),
				'subtitle' => __('Type unique slug that will be used with permalinks', 'mauna'),
				'type' => 'text',
				'default' => '',
			),

			array(
				'id'       => 'mauna_promotion_circle_enable',
				'title' => __( 'Show decoration', 'mauna' ),
				'subtitle' => __('Select if announcements page should contain decoration element.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),

			array(
				'id'       => 'mauna_promotion_type_decoration',
				'title' => __( 'Decoration element', 'mauna' ),
				'subtitle' => __('Select type of decoration element.', 'mauna'),
				'type' => 'button_set',
				'options' => array(
					'circle' => __('Circle', 'mauna'),
					'triangle' => __('Triangle', 'mauna'),
					'square' => __('Square', 'mauna'),
					'custom' => __('Custom SVG', 'mauna'),
					
				),
				'default' => 'circle',
				'required' => array( 'mauna_promotion_circle_enable', '=', true )
			),
			array(
				'id'       => 'mauna_promotion_type_decoration_custom',
				'title' => __( 'Custom SVG element', 'mauna' ),
				'subtitle' => __('Select SVG element.', 'mauna'),
				'type' => 'media',
				'required' => array( 'mauna_promotion_type_decoration', '=', 'custom' )
			),
			array(
				'id'       => 'mauna_promotion_circle_position',
				'type' 	   => 'button_set',
				'title' => __( 'Decoration position', 'mauna' ),
				'subtitle'  => __( 'Define position for decoration element', 'mauna' ),
				'options' => array(
					'circle_left' => __('Left', 'mauna'),
					'circle_center' => __('Center', 'mauna'),
					'circle_right' => __('Right', 'mauna'),
					
				),
				'default' => 'circle_center',
				'required' => array( 'mauna_promotion_circle_enable', '=', true )
			),
			array(
				'id' => 'mauna_promotion_arrow',
				'title' => __( 'Slider arrows', 'mauna' ),
				'subtitle' => __('Select if announcements should contain arrows.', 'mauna'),
				'type' => 'switch',
				'default' => false,
			),
			array(
				'id' => 'mauna_promotion_single_navigation',
				'type' => 'select',
				'title' => __('Select single annoucement navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-dark',
			),
			// array(
			// 	'id' => 'mauna_promotion_title',
			// 	'title' => __( 'Announcements content', 'mauna' ),
			// 	'subtitle' => __('Select if announcements should contain title & description.', 'mauna'),
			// 	'type' => 'switch',
			// 	'default' => true,
			// ),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_promotion_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_promotion_title_typo',
				'type'        => 'typography', 
				'title'       => __('Header title', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.promotion-news-header header h3'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'font-size' => '30px',
					'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_promotion_headers_typo',
				'type'        => 'typography', 
				'title'       => __('Headers', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.promotion-news-content h1, .promotion-news-content h2, .promotion-news-content h3, .promotion-news-content h4, .promotion-news-content h5, .promotion-news-content h6'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
					'letter-spacing' => '3px',
					// 'text-align' => 'center',
				),
			),
			array(
				'id'       => 'mauna_promotion_content_typo',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.promotion-news-content .content, .promotion-news-content .content a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'none',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '1px',
					'font-size' => '18px'
				),
			),
			array(
				'id'       => 'mauna_promotion_nav_typo',
				'type'        => 'typography', 
				'title'       => __('Navigation in content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.promotion-news-header .menu-default .menu-item a'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Lato', 
					'google'      => true,
					'letter-spacing' => '2px',
					'font-size' => '16px',
				),
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_promotion_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
				'id'       => 'mauna_promotion_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for background', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('background-color' => '.promotion-news-wrapper'),
			),	
			array(
				'id'       => 'mauna_promotion_overlay_color',
				'type'     => 'color',
				'title'    => __( 'Image overlay color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for overlay', 'mauna' ),
				'default'  => 'rgba(0,0,0,0.5)',
				'validate' => '',
				'output'   => array('background-color' => '.promotion-news-overlay'),
			),	
			array(
				'id'       => 'mauna_promotion_header_color',
				'type'     => 'color',
				'title'    => __( 'Header color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for default template title & content navigation.', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color' => '.promotion-news .promotion-news-header header, .promotion-news .header-wrapper a'),
			),	
			array(
				'id'       => 'mauna_promotion_color_accent',
				'type'     => 'color',
				'title'    => __( 'Accent color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for decoration & menu item hover.', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('stroke' => '.promotion-news .decoration svg'),
			),
			array(
				'id'   =>'mauna_promotion_divider_1',
				'type' => 'divide'
			),
			array(
				'id'       => 'mauna_promotion_content_color',
				'type'     => 'color',
				'title'    => __( 'Content color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for announcements content', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color' => '.promotion-news-content .content', 'stroke' => '.promotion-news .portfolio-arrow svg'),
			),	
			array(
				'id'       => 'mauna_promotion_overlay1_color',
				'type'     => 'color',
				'title'    => __( 'Content overlay 1 color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for content overlay', 'mauna' ),
				'default'  => 'rgba(0,0,0,.5)',
				'validate' => '',
				'output'   => array('background-color' => '.promotion-news-content-wrapper:before'),
			),	
			array(
				'id'       => 'mauna_promotion_overlay2_color',
				'type'     => 'color',
				'title'    => __( 'Content overlay 2 color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for content overlay', 'mauna' ),
				'default'  => 'rgba(85,218,165,.5)',
				'validate' => '',
				'output'   => array('background-color' => '.promotion-news-content-wrapper:after'),
			),
			// array(
			//     'id'   =>'mauna_promotion_divider_2',
			//     'type' => 'divide'
			// ),
			array(
				'id'       => 'mauna_promotion_arrow_bg_color',
				'type'     => 'color',
				'title'    => __( 'Button "prev/next slide" background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for button background', 'mauna' ),
				'default'  => 'rgba(0,0,0,0.3)',
				'validate' => '',
				'output'   => array('background-color'=>'.promotion-news .portfolio-arrow'),
			),		
			// array(
			// 	'id'       => 'mauna_promotion_arrow_color',
			// 	'type'     => 'color',
			// 	'title'    => __( 'Button "prev/next slide" color', 'mauna' ),
			// 	'subtitle' => __( 'Select color and opacity for announcements hover', 'mauna' ),
			// 	'default'  => '#111',
			// 	'validate' => '',
			// 	'output'   => array('stroke' => '.promotion-news .portfolio-arrow svg'),
			// ),	
			// array(
			// 	'id'       => 'mauna_promotion_hover_arrow_color',
			// 	'type'     => 'color',
			// 	'title'    => __( 'Button "prev/next slide" hover color', 'mauna' ),
			// 	'subtitle' => __( 'Select color and opacity for button hover', 'mauna' ),
			// 	'default'  => '#55DAA5',
			// 	'validate' => '',
			// 	'output'   => array('stroke' => '.promotion-news .arrow-hover line, .promotion-news .portfolio-arrow:hover svg'),
			// ),	
			array(
				'id'   =>'mauna_promotion_divider_3',
				'type' => 'divide'
			),

			array(
				'id'       => 'mauna_promotion_post_bg_color',
				'type'     => 'color',
				'title'    => __( 'Announcement background', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for single post background', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('background-color'=>'.promotion-single-post, .promotion-single-post .blog-footer'),
			),		
			array(
				'id'       => 'mauna_promotion_post_color',
				'type'     => 'color',
				'title'    => __( 'Announcement color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for single post text color', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('color'=>'.promotion-single-post, .promotion-single-post .blog-footer .footer-content, .promotion-single-post .blog-footer .footer-content a, .promotion-single-post .content a'),
			),	
			array(
				'id'       => 'mauna_promotion_hover_post',
				'type'     => 'color',
				'title'    => __( 'Announcement hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for single post hover', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background'=>' .promotion-single-post .link-hover:before'),
			),	
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'WooCommerce', 'mauna' ),
		'id'               => 'mauna_commerce',
		'icon'             => 'el el-shopping-cart',
		'subsection'       => false,
		'fields'           => array(
			array(
				'id'       => 'mauna_woo_enable',
				'type' => 'switch',
				'title'    => __( 'Enable WooCommerce styles', 'mauna' ),
				'subtitle' => __( 'Enable if you have active WooCommerce plugin', 'mauna' ),
				'default' => false,
			),	
			array(
				'id' => 'mauna_woo_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-dark',
			),
		),
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Typography', 'mauna' ),
		'id'               => 'mauna_commerce_typography',
		'subsection'       => true,
		'fields'           => array(
			array(
			    'id'   => 'mauna_woo_typo_info',
			    'type' => 'info',
			    'notice' => false,
			    'desc' => __('Please enable WooCommerce styles.', 'mauna'),
			    'required'    => array('mauna_woo_enable', '!=', '1'),
			),
			array(
				'id'       => 'mauna_commerce_headers_typo',
				'type'        => 'typography', 
				'title'       => __('Headers / product title', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.woocommerce h1.page-title, .woocommerce ul.products li.product h3, .woocommerce div.product .product_title, .woocommerce ul.products li.product .onsale, .woocommerce div.product .woocommerce-tabs h2, .woocommerce div.product .related h2, .woocommerce table.shop_table td.product-name a, .woocommerce .cart-collaterals .cart_totals h2, .woocommerce-page .cart-collaterals .cart_totals h2, #reviews #reply-title, .woocommerce-Tabs-panel #reviews #review_form_wrapper label, .woocommerce .woocommerce-ordering .orderby, .woocommerce span.onsale, .woocommerce-Tabs-panel #reviews #comments .description p, .woocommerce-Tabs-panel #reviews #comments .description a, .woocommerce form.cart .variations select, .woocommerce .variations .label label, .woocommerce .cart .coupon .input-text, .woocommerce-billing-fields h3, #order_review_heading, #ship-to-different-address, .woocommerce .cart_item td.product-name, .woocommerce-billing-fields input, .woocommerce-billing-fields textarea, .woocommerce-billing-fields .select2-choice span, .woocommerce td.product-name dl.variation, .woocommerce .addresses .title h3, .woocommerce .cross-sells h2, .woocommerce div.product .upsells h2, .woocommerce .woocommerce-checkout .woocommerce-billing-fields h3, .cart-offcanvas .show-cart li .list-product h5, .woocommerce-account .woocommerce h2'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => false,
				'font-size'   => false,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-family' => 'Playfair Display', 
					'google'      => true,
				),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),
			array(
				'id'       => 'mauna_commerce_content_typo',
				'type'        => 'typography', 
				'title'       => __('Content', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.woocommerce .price, .woocommerce div.product .summary > div p, .woocommerce .woocommerce-review-link, .woocommerce div.product .product_meta, .woocommerce div.product .woocommerce-tabs .panel p, .woocommerce-pagination a, .woocommerce-pagination, .woocommerce .cart_item td.product-name strong, .woocommerce .cart .product-price span, .woocommerce .cart .product-subtotal span, .woocommerce div.quantity .qty, .woocommerce .cart_totals .amount, .cart_totals, .cart_totals input, .cart_totals select, .woocommerce-page .page-content .content, .woocommerce-page .page-content .content a, .woocommerce-page .page-content .content p, .cart-offcanvas .show-cart li .list-product .price-product'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => false,
				'default'     => array(
					'text-transform' => '',
					'font-family' => 'Lato', 
					'google'      => true,
					'text-align' => 'left',
					'font-size' => '18px'
				),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),
			array(
				'id'       => 'mauna_commerce_links_typo',
				'type'        => 'typography', 
				'title'       => __('Links / buttons', 'mauna'),
				'google'      => true, 
				'font-backup' => true,
				'output'      => array('.woocommerce-breadcrumb a, .woocommerce .woocommerce-breadcrumb, .woocommerce-result-count, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce div.product .woocommerce-tabs ul.tabs li a, .woocommerce .variations .value a, .woocommerce .cart thead th, .woocommerce .cart .button, .woocommerce-cart .wc-proceed-to-checkout a.checkout-button, .cart-subtotal th, .order-total th, .shipping th, .woocommerce .shipping .shipping-calculator-button, #ship-to-different-address label, .woocommerce table.shop_table th, .woocommerce #payment #place_order, .woocommerce-page #payment #place_order, .woocommerce .mauna-single-product a.added_to_cart, .woocommerce-page .page-content .content a.button, .cart-offcanvas .summation .btn-cart a, .woocommerce-page .woocommerce-MyAccount-navigation .woocommerce-MyAccount-navigation-link a, .woocommerce-account .addresses .title .edit, .woocommerce-account .woocommerce .woocommerce-LostPassword a, .cart-offcanvas .cart-offcanvas-close'),
				'units'       =>'px',
				'color'       => false, 
				'all_styles'  => true,
				'text-transform' => true,
				'text-align'  => true,
				'font-size'   => true,
				'line-height' => false,
				'letter-spacing' => true,
				'default'     => array(
					'text-transform' => 'uppercase',
					'font-size' => '12px',
					'letter-spacing' => '3px',
					'font-family' => 'Lato', 
					'google'      => true,
					'font-weight' => '700',
					'text-align' => 'left',
				),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Colors', 'mauna' ),
		'id'               => 'mauna_commerce_colors',
		'subsection'       => true,
		'fields'           => array(
			array(
			    'id'   => 'mauna_woo_colors_info',
			    'type' => 'info',
			    'notice' => false,
			    'desc' => __('Please enable WooCommerce styles.', 'mauna'),
			    'required'    => array('mauna_woo_enable', '!=', '1'),
			),
			array(
				'id'       => 'mauna_woo_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background color', 'mauna' ),
				'subtitle' => __( 'Select background color for WooCommerce pages', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'required'    => array('mauna_woo_enable', '=', '1'),
				'output'   => array('background'=>'.mauna-woocommerce, .woocommerce-cart, .woocommerce-checkout', 'color' => '.woocommerce div.product form.cart button.single_add_to_cart_button:hover, .page-content .woocommerce .cart-collaterals .cart_totals .wc-proceed-to-checkout a:hover, .woocommerce .cart-collaterals .cart_totals .shipping-calculator-button:hover, .woocommerce .cart .button:hover, .woocommerce .cart input.button:hover, .page-content .woocommerce .shipping .woocommerce-shipping-calculator button.button:hover, .woocommerce #payment #place_order:hover, .woocommerce-MyAccount-content .woocommerce-Button:hover, .woocommerce input.button:hover'),
			),	
			array(
				'id'       => 'mauna_woo_primary_color',
				'type'     => 'color',
				'title'    => __( 'Primary color', 'mauna' ),
				'subtitle' => __( 'Select color for buttons background and accents', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'output'   => array('background'=>'.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce div.product form.cart div.quantity .minus:hover, .woocommerce div.product form.cart div.quantity .plus:hover', 'border-color' => '.woocommerce div.product .woocommerce-tabs ul.tabs li.active', 'color' => '.woocommerce div.product p.stock, .woocommerce .product-remove'),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),	

			array(
				'id'       => 'mauna_woo_content_color',
				'type'     => 'color',
				'title'    => __( 'Content color', 'mauna' ),
				'subtitle' => __( 'Select color for content', 'mauna' ),
				'default'  => '#111',
				'validate' => '',
				'output'   => array('color'=>'.woocommerce, .woocommerce a, .woocommerce ul.products li.product a, .woocommerce div.product p.price, .woocommerce div.product span.price, .woocommerce ul.products li.product .price, .woocommerce span.onsale, .woocommerce #reviews #comments ol.commentlist li .comment-text p.meta, .woocommerce div.product form.cart button.single_add_to_cart_button, .woocommerce .cart.shop_table .cart_item .product-name a, .woocommerce .cart.shop_table thead th, .woocommerce-cart div.quantity .qty, .woocommerce-cart table.cart td.actions .coupon .input-text, .woocommerce .cart-collaterals .cart_totals label, .woocommerce .cart-collaterals .cart_totals .shipping-calculator-button, .woocommerce .cart-collaterals .cart_totals input, .woocommerce .cart-collaterals .cart_totals select, .woocommerce div.product form.cart .variations label, .woocommerce div.product form.cart .variations select', 'background-color' => '.woocommerce .onsale:after, .woocommerce div.product .product_meta:before'),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),	
			// .woocommerce .woocommerce-breadcrumb, .woocommerce .woocommerce-ordering select, .woocommerce ul.products li.product .onsale, .woocommerce nav.woocommerce-pagination ul.page-numbers li .current, .woocommerce div.product form.cart div.quantity .qty, .woocommerce div.product .woocommerce-tabs ul.tabs li a, .woocommerce-Tabs-panel #reviews #review_form_wrapper label, .woocommerce-Tabs-panel #reviews #review_form_wrapper textarea
			array(
				'id'       => 'mauna_woo_border_color',
				'type'     => 'color',
				'title'    => __( 'Border color', 'mauna' ),
				'subtitle' => __( 'Select color for borders and separators', 'mauna' ),
				'default'  => '#ddd',
				'validate' => '',
				'output'   => array('border-color'=>'.woocommerce div.product .woocommerce-tabs, .woocommerce form.cart .quantity .plus, .woocommerce form.cart .quantity .minus, .woocommerce form.cart .quantity .qty, .woocommerce-cart div.quantity .minus, .woocommerce-cart div.quantity .plus, .woocommerce-cart div.quantity .qty, .woocommerce .woocommerce-ordering select, .woocommerce-Tabs-panel #reviews #review_form_wrapper textarea, .woocommerce-Tabs-panel #reviews #review_form_wrapper input, .woocommerce .cart thead, #add_payment_method table.cart td.actions .coupon .input-text, .woocommerce-cart table.cart td.actions .coupon .input-text, .woocommerce-checkout table.cart td.actions .coupon .input-text, .woocommerce .cart-collaterals .cart_totals, .woocommerce .cart-collaterals .cart_totals tbody > tr th, .woocommerce .cart-collaterals .cart_totals tbody > tr td, .woocommerce table.shop_table tbody > tr:last-of-type, .woocommerce .woocommerce-checkout-review-order-table thead, .woocommerce .woocommerce-checkout-review-order-table tfoot tr, #add_payment_method #payment, .woocommerce-cart #payment, .woocommerce-checkout #payment, .woocommerce .order_details tfoot tr, .woocommerce div.product form.cart .variations select'),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),
			array(
				'id'       => 'mauna_woo_hover_color',
				'type'     => 'color',
				'title'    => __( 'Hover color', 'mauna' ),
				'subtitle' => __( 'Select hover color for WooCommerce elements', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',

				'required'    => array('mauna_woo_enable', '=', '1'),
				'output' => array('background-color' => '.woocommerce-pagination ul.page-numbers li a:before, .woocommerce .mauna-single-product a.add_to_cart_button:hover, .woocommerce .mauna-single-product a.added_to_cart:hover, .woocommerce-product-rating .woocommerce-review-link:before, .woocommerce div.product form.cart button.single_add_to_cart_button:hover, .page-content .woocommerce .cart-collaterals .cart_totals .wc-proceed-to-checkout a:hover, .woocommerce .cart-collaterals .cart_totals .shipping-calculator-button:hover, .woocommerce div.product .product_meta a:before, .woocommerce div.product .woocommerce-tabs ul.tabs li a:before, .woocommerce-Tabs-panel #reviews #review_form_wrapper .form-submit:before, .woocommerce div.product form.cart .variations .value a:before, .woocommerce div.product div.images >a:before, .woocommerce div.product div.images >a:after, .woocommerce-cart table.cart .product-thumbnail >a:before, .woocommerce-cart table.cart .product-thumbnail >a:after, .woocommerce .cart .button:hover, .woocommerce .cart input.button:hover, .page-content .woocommerce .shipping .woocommerce-shipping-calculator button.button:hover, .woocommerce .cart.shop_table .cart_item .product-name a:before, .woocommerce-cart div.quantity .plus:hover, .woocommerce-cart div.quantity .minus:hover, .woocommerce #payment #place_order:hover, .woocommerce-page .woocommerce-MyAccount-navigation .woocommerce-MyAccount-navigation-link a:before, .woocommerce input.button:hover, .woocommerce-account .woocommerce .woocommerce-LostPassword a:before')
			),	
			array(
				'id'       => 'mauna_woo_stars_color',
				'type'     => 'color',
				'title'    => __( 'Stars color', 'mauna' ),
				'subtitle' => __( 'Select color for rating', 'mauna' ),
				'default'  => '#f7d364',
				'validate' => '',
				'output'   => array('color'=>'.woocommerce ul.products li.product .star-rating, .woocommerce .star-rating span, .woocommerce .stars span a, .woocommerce .star-rating:before'),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),

			array(
				'id'       => 'mauna_woo_dynamic_cart_background',
				'type'     => 'color',
				'title'    => __( 'Dynamic cart background', 'mauna' ),
				'subtitle' => __( 'Select background color for cart', 'mauna' ),
				'default'  => '#222',
				'validate' => '',
				'output'   => array('background-color'=>'.cart-offcanvas, .cart-offcanvas .summation'),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),

			array(
				'id'       => 'mauna_woo_dynamic_cart_text_color',
				'type'     => 'color',
				'title'    => __( 'Dynamic cart text color', 'mauna' ),
				'subtitle' => __( 'Select text color for cart', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'output'   => array('color'=>'.cart-offcanvas, .cart-offcanvas .summation .btn-cart a, .cart-offcanvas a h5'),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),

			array(
				'id'       => 'mauna_woo_dynamic_cart_additional_color',
				'type'     => 'color',
				'title'    => __( 'Dynamic cart additional color', 'mauna' ),
				'subtitle' => __( 'Select additional color for cart borders and close button', 'mauna' ),
				'default'  => 'rgba(255,255,255,0.3)',
				'validate' => '',
				'output'   => array('background-color'=>'.cart-offcanvas-close', 'border-color'=>'.cart-offcanvas .summation .btn-cart a:nth-child(1n)'),
				'required'    => array('mauna_woo_enable', '=', '1'),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'            => __( 'Other WP pages', 'mauna' ),
		'id'               => 'mauna_other_pages_navigation',
		'subsection'       => false,
		'fields'           => array(
			array(
				'id' => 'mauna_other_pages_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-dark',
			),
		)
	) );


	Redux::setSection( $opt_name, array(
		'icon'   => 'el el-download-alt',
		'title'  => __( 'Demo import', 'mauna' ),
		'fields' => array(
			array(
				'id' => 'mauna_demo_select',
				'type'     => 'image_select',
				'title'    => __('Select demo', 'mauna'), 
				'subtitle' => __('Select style of a demo to import.', 'mauna'),
				// 'tiles'    => true,
				'width'    => 200,
				'height'    => 200,
				'options'  => array(
					'3'      => array(
						'alt'   => '2 Column Right', 
						'img'   => 'http://mauna.puruno.com/img/3.jpg'
					),
					'1'      => array(
						'alt'   => '1 Column', 
						'img'   => 'http://mauna.puruno.com/img/1.jpg'
					),
					'2'      => array(
						'alt'   => '2 Column Left', 
						'img'   => 'http://mauna.puruno.com/img/2.jpg'
					),
					'4'      => array(
						'alt'   => '1 Column', 
						'img'   => 'http://mauna.puruno.com/img/4.jpg'
					),
					'5'      => array(
						'alt'   => '2 Column Left', 
						'img'   => 'http://mauna.puruno.com/img/5.jpg'
					),
					'6'      => array(
						'alt'   => '2 Column Right', 
						'img'   => 'http://mauna.puruno.com/img/6.jpg'
					),
					'7'      => array(
						'alt'   => '2 Column Right', 
						'img'   => 'http://mauna.puruno.com/img/7.jpg'
					),
					'8'      => array(
						'alt'   => '2 Column Right', 
						'img'   => 'http://mauna.puruno.com/img/8.jpg'
					),
					'9'      => array(
						'alt'   => '2 Column Right', 
						'img'   => 'http://mauna.puruno.com/img/9.jpg'
					),
				),
				'default' => '1'
			),
			array(
				'id' => 'mauna_demo_content',
				'type'     => 'button_set',
				'title'    => __( 'Type of import', 'mauna' ),
				'subtitle' => __( 'Select if you want to import demo content with settings or settings only.', 'mauna' ),
				'description' => '<small style="color: #DC6262;">* please note that importing content will remove every existing posts and settings. <strong>Our demo does not contain photos.</strong></small>',
				'options'  => array(
					'content' => 'Content with settings *',
					'settings' => 'Only settings',
				),
				'default' => 'settings',
			),
			array(
				'id' => 'demo_import',
				'type' => 'demo_import',
				'class' => 'demo_import'
			),
		)
	));




	/*
	 * <--- END SECTIONS
	 */


	/*
	 *
	 * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
	 *
	 */

	/*
	*
	* --> Action hook examples
	*
	*/

	// If Redux is running as a plugin, this will remove the demo notice and links
	// add_action( 'redux/loaded', 'remove_demo' );

	// Function to test the compiler hook and demo CSS output.
	// Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
	//add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

	// Change the arguments after they've been declared, but before the panel is created
	//add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

	// Change the default value of a field after it's been set, but before it's been useds
	//add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

	// Dynamically add a section. Can be also used to modify sections/fields
	//add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

	/**
	 * This is a test function that will let you see when the compiler hook occurs.
	 * It only runs if a field    set with compiler=>true is changed.
	 * */
	if ( ! function_exists( 'compiler_action' ) ) {
		function compiler_action( $options, $css, $changed_values ) {
			echo '<h1>The compiler hook has run!</h1>';
			echo "<pre>";
			print_r( $changed_values ); // Values that have changed since the last save
			echo "</pre>";
			//print_r($options); //Option values
			//print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
		}
	}

	/**
	 * Custom function for the callback validation referenced above
	 * */
	if ( ! function_exists( 'redux_validate_callback_function' ) ) {
		function redux_validate_callback_function( $field, $value, $existing_value ) {
			$error   = false;
			$warning = false;

			//do your validation
			if ( $value == 1 ) {
				$error = true;
				$value = $existing_value;
			} elseif ( $value == 2 ) {
				$warning = true;
				$value   = $existing_value;
			}

			$return['value'] = $value;

			if ( $error == true ) {
				$return['error'] = $field;
				$field['msg']    = 'your custom error message';
			}

			if ( $warning == true ) {
				$return['warning'] = $field;
				$field['msg']      = 'your custom warning message';
			}

			return $return;
		}
	}

	/**
	 * Custom function for the callback referenced above
	 */
	if ( ! function_exists( 'redux_my_custom_field' ) ) {
		function redux_my_custom_field( $field, $value ) {
			print_r( $field );
			echo '<br/>';
			print_r( $value );
		}
	}


	/**
	 * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
	 * */
	if ( ! function_exists( 'change_arguments' ) ) {
		function change_arguments( $args ) {
			//$args['dev_mode'] = true;

			return $args;
		}
	}

	/**
	 * Filter hook for filtering the default value of any given field. Very useful in development mode.
	 * */
	if ( ! function_exists( 'change_defaults' ) ) {
		function change_defaults( $defaults ) {
			$defaults['str_replace'] = 'Testing filter hook!';

			return $defaults;
		}
	}

	/**
	 * Removes the demo link and the notice of integrated demo from the redux-framework plugin
	 */
	if ( ! function_exists( 'remove_demo' ) ) {
		function remove_demo() {
			// Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
			if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
				remove_filter( 'plugin_row_meta', array(
					ReduxFrameworkPlugin::instance(),
					'plugin_metalinks'
				), null, 2 );

				// Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
				remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
			}
		}
	}

