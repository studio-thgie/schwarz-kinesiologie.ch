<?php

// INCLUDE THIS BEFORE you load your ReduxFramework object config file.


// You may replace $redux_opt_name with a string if you wish. If you do so, change loader.php
// as well as all the instances below.
$redux_opt_name = "mauna_redux";



function mauna_get_rev_sliders_array() {
	// Add This only if RevSlider is Activated
	if (class_exists('RevSliderAdmin')) {
		/* get revolution array */
		$slider = new RevSlider();
		$arrSliders = $slider->getArrSlidersShort();
		return $arrSliders;
	} else {
		return false;
	}
}



if ( !function_exists( "redux_add_metaboxes" ) ):
	function redux_add_metaboxes($metaboxes) {

	$page = array();
	$page[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-address-book',
		'fields'        => array(
			array(
				'id' => 'mauna_page_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-dark',
			),
			array(
				'id' => 'mauna_page_intro',
				'title' => __( 'Show featured image', 'mauna' ),
				'subtitle' => __('Select if default template should contain featured image as intro.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_page_title',
				'title' => __( 'Show title on featured image', 'mauna' ),
				'subtitle' => __('Select if intro should contain title.', 'mauna'),
				'type' => 'switch',
				'default' => true,
				'required' => array( 'mauna_page_intro', '=', true )
			),
			array(
				'id'       => 'mauna_page_title_font_size',
				'title' => __( 'Title on featured image font size', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'typography',
				'google' => false,
				'font-style' => false,
				'font-weight' => false,
				'font-family' => false,
				'subset' => false,
				'line-height' => false,
				// 'letter-spacing' => true,
				'color' => false,
				'text-align' => false,
				'default' => '',
				'output' => array('.default-template-title h3'),
				'required' => array( 'mauna_page_title', '=', true )
			),
			array(
				'id'       => 'mauna_page_title_letter_spacing',
				'title' => __( 'Title on featured image letter spacing (in px).', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '',
				'required' => array( 'mauna_page_title', '=', true )
			),
		),
	);


	$default_page = array();
	$default_page[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-address-book',
		'fields'        => array(
			array(
				'id' => 'mauna_default_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id' => 'mauna_default_nav_list',
				'title' => __( 'Navigation for content', 'mauna' ),
				'subtitle' => __('Select navigation to display.', 'mauna'),
				'type' => 'select',
				'data' => 'menus',
			),
		
			array(
				'id'       => 'mauna_default_title_enable',
				'title' => __( 'Show title', 'mauna' ),
				'subtitle' => __('Select if default template should contain title.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_default_title_font_size',
				'title' => __( 'Title font size', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'typography',
				'google' => false,
				'font-style' => false,
				'font-weight' => false,
				'font-family' => false,
				'subset' => false,
				'line-height' => false,
				// 'letter-spacing' => true,
				'color' => false,
				'text-align' => false,
				'default' => '',
				'output' => array('.default-header h3'),
				'required' => array( 'mauna_default_title_enable', '=', true )
			),
			array(
				'id'       => 'mauna_default_title_letter_spacing',
				'title' => __( 'Title letter spacing (in px).', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '',
				'required' => array( 'mauna_default_title_enable', '=', true )
			),
			array(
				'id'       => 'mauna_default_circle_enable',
				'title' => __( 'Show decoration', 'mauna' ),
				'subtitle' => __('Select if default template should contain decoration element.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_default_type_decoration',
				'title' => __( 'Decoration element', 'mauna' ),
				'subtitle' => __('Select type of decoration element.', 'mauna'),
				'type' => 'button_set',
				'options' => array(
					'circle' => __('Circle', 'mauna'),
					'triangle' => __('Triangle', 'mauna'),
					'square' => __('Square', 'mauna'),
					'custom' => __('Custom', 'mauna'),
					
				),
				'default' => 'circle',
				'required' => array( 'mauna_default_circle_enable', '=', true )
			),
			array(
				'id'       => 'mauna_default_type_decoration_custom',
				'title' => __( 'Custom SVG element', 'mauna' ),
				'subtitle' => __('Select SVG element.', 'mauna'),
				'type' => 'media',
				'required' => array( 'mauna_default_type_decoration', '=', 'custom' )
			),
			array(
				'id'       => 'mauna_default_circle_position',
				'type' 	   => 'button_set',
				'title' => __( 'Decoration position', 'mauna' ),
				'subtitle'  => __( 'Define position for decoration element', 'mauna' ),
				'options' => array(
					'circle_left' => __('Left', 'mauna'),
					'circle_center' => __('Center', 'mauna'),
					'circle_right' => __('Right', 'mauna'),
				),
				'default' => 'circle_center',
				'required' => array( 'mauna_default_circle_enable', '=', true )
			),
		),
	);

	$default2_page = array();
	$default2_page[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-address-book',
		'fields'        => array(
			array(
				'id' => 'mauna_default2_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id' => 'mauna_default2_nav_list',
				'title' => __( 'Navigation for content', 'mauna' ),
				'subtitle' => __('Select navigation to display.', 'mauna'),
				'type' => 'select',
				'data' => 'menus',
			),
			array(
				'id'       => 'mauna_default2_title_enable',
				'title' => __( 'Show title', 'mauna' ),
				'subtitle' => __('Select if default template should contain title.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_default2_title_font_size',
				'title' => __( 'Title font size', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'typography',
				'google' => false,
				'font-style' => false,
				'font-weight' => false,
				'font-family' => false,
				'subset' => false,
				'line-height' => false,
				// 'letter-spacing' => true,
				'color' => false,
				'text-align' => false,
				'default' => '',
				'output' => array('.default-header-2 h3'),
				'required' => array( 'mauna_default2_title_enable', '=', true )
			),
			array(
				'id'       => 'mauna_default2_title_letter_spacing',
				'title' => __( 'Title letter spacing (in px).', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '',
				'required' => array( 'mauna_default2_title_enable', '=', true )
			),
		),
	);

	$home = array();
	$home[] =  array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-address-book',
		'fields'        => array(
		array(
			'id' => 'mauna_home_navigation',
			'type' => 'select',
			'title' => __('Select navigation type', 'mauna'),
			'options'  => array(
				'none' => __('None', 'mauna'),
				'large-light' => __('Light large', 'mauna'),
				'small-light' => __('Light small', 'mauna'),
				'large-dark' => __('Dark large', 'mauna'),
				'small-dark' => __('Dark small', 'mauna'),
			),
			'select2' => array('allowClear'=>false),
			'default' => 'large-light',
		),
		array(
			'id' => 'mauna_home_show_burger',
			'title' => __( 'Show burger nav', 'mauna' ),
			'type' => 'switch',
			'default' => true,
		),
		array(
			'id' => 'mauna_home_show_logo',
			'title' => __( 'Show logo', 'mauna' ),
			'type' => 'switch',
			'default' => true,
		),
		array(
			'id' => 'mauna_home_background_type',
			'type' => 'select',
			'options' => array(
				'static' => __('Static background', 'mauna'),
				'slider' => __('Fullscreen slider', 'mauna'),
				'video' => __('Video background', 'mauna'),
				'revslider' => __('Revolution slider', 'mauna'),
			),
			'default' => 'static',
			'select2' => array('allowClear'=>false),
			'title'	=> __( 'Select home background', 'mauna' ),
		),

		array(
			'id' => 'mauna_home_background_images',
			'type' => 'gallery',
			'title' => __('Background slides', 'mauna'),
			'required' => array('mauna_home_background_type', '=', 'slider'),
		),
		array(
			'id' => 'mauna_home_slides_duration',
			'type' => 'text',
			'title' => __('Insert slides duration', 'mauna'),
			'subtitle' => __('In miliseconds. For example, insert 5000 for 5sec (default 5000)', 'mauna'),
			'default' => '5000',
			'required' => array('mauna_home_background_type', '=', 'slider'),
		),
		array(
			'id' => 'mauna_home_slides_transition_duration',
			'type' => 'text',
			'title' => __('Insert slides transition duration', 'mauna'),
			'subtitle' => __('In miliseconds. For example, insert 5000 for 5sec (default 1000)', 'mauna'),
			'default' => '1000',
			'required' => array('mauna_home_background_type', '=', 'slider'),
		),
		array(
			'id' => 'mauna_home_slides_animation',
			'type' => 'select',
			'title' => __('Animation', 'mauna'),
			'options'  => array(
				'none' => __('None', 'mauna'),
				'parallax' => __('Parallax on mouse', 'mauna'),
				'kenburn' => __('Ken Burns', 'mauna'),
			),
			'select2' => array('allowClear'=>false),
			'default' => 'parallax',
			'required' => array('mauna_home_background_type', '=', 'slider'),
		),

		array(
			'id' => 'mauna_home_slides_transition',
			'type' => 'select',
			'title' => __('Transition', 'mauna'),
			'options'  => array(
				'fade' => __('Fade', 'mauna'),
				'fade2' => __( 'Fade 2', 'mauna' ),
				'slideLeft' => __( 'Slide left', 'mauna' ),
				'slideLeft2' => __( 'Slide left 2', 'mauna' ),
				'slideRight' => __( 'Slide right', 'mauna' ),
				'slideRight2' => __( 'Slide right 2', 'mauna' ),
				'slideUp' => __( 'Slide up', 'mauna' ),
				'slideUp2' => __( 'Slide up 2', 'mauna' ),
				'slideDown' => __( 'Slide down', 'mauna' ),
				'slideDown2' => __( 'Slide down 2', 'mauna' ),
				'zoomIn' => __( 'Zoom in', 'mauna' ),
				'zoomIn2' => __( 'Zoom in 2', 'mauna' ),
				'zoomOut' => __( 'Zoom out', 'mauna' ),
				'zoomOut2' => __( 'Zoom out 2', 'mauna' ),
				'swirlLeft' => __( 'Swirl left', 'mauna' ),
				'swirlLeft2' => __( 'Swirl left 2', 'mauna' ),
				'swirlRight' => __( 'Swirl right', 'mauna' ),
				'swirlRight2' => __( 'Swirl right 2', 'mauna' ),
				'burn' => __( 'Burn', 'mauna' ),
				'burn2' => __( 'Burn 2', 'mauna' ),
				'blur' => __( 'Blur', 'mauna' ),
				'blur2' => __( 'Blur 2', 'mauna' ),
				'flash' => __( 'Flash', 'mauna' ),
				'flash2' => __( 'Flash 2', 'mauna' ),
				'random' => __( 'Random', 'mauna' ),
			),
			'select2' => array('allowClear'=>false),
			'default' => 'fade',
			'required' => array('mauna_home_background_type', '=', 'slider'),
		),

		array(
			'id' => 'mauna_home_color_overlay',
			'type' => 'color',
			'title' => __( 'Color overlay', 'mauna'),
			'validate' => '',
			'required' => array('mauna_home_background_type', '!=',  'revslider'),
		),

		array(
			'id' => 'mauna_home_video',
			'type' => 'text',
			'title' => __('YouTube video link', 'mauna'),
			'required' => array('mauna_home_background_type', '=', 'video'),
		),

		array(
			'id' => 'mauna_home_video_start',
			'type' => 'text',
			'title' => __('Start video at (in seconds)', 'mauna'),
			'default' => '0',
			'required' => array('mauna_home_background_type', '=', 'video'),
		),
		array(
			'id' => 'mauna_home_video_mute',
			'type' => 'checkbox',
			'title' => __('Mute video', 'mauna'),
			'required' => array('mauna_home_background_type', '=', 'video'),
			'default' => 1,
		),
		array(
			'id' => 'mauna_home_video_loop',
			'type' => 'checkbox',
			'title' => __('Loop video', 'mauna'),
			'required' => array('mauna_home_background_type', '=', 'video'),
			'default' => 1,
		),
		array(
			'id' => 'mauna_home_video_auto_play',
			'type' => 'checkbox',
			'title' => __('Auto play', 'mauna'),
			'required' => array('mauna_home_background_type', '=', 'video'),
			'default' => 1,
		),
		array(
			'id' => 'mauna_home_video_controls',
			'type' => 'checkbox',
			'title' => __('Show video controls', 'mauna'),
			'required' => array('mauna_home_video_auto_play', '=', 1),
			'default' => 0,
		),
		// array(
		// 	'id' => 'mauna_home_mask_toggle',
		// 	'type' => 'button_set',
		// 	'title' => __('Video overlay', 'mauna'),
		// 	'options'  => array(
		// 		'none' => __('None', 'mauna'),
		// 		'mask' => __( 'Mask overlay', 'mauna' ),
		// 	),
		// 	'default' => 'none',
		// 	'required' => array('mauna_home_background_type', '=', 'video'),
		// ),
		// array(
		// 	'id' => 'mauna_home_video_color_overlay',
		// 	'type' => 'color',
		// 	'title' => __( 'Color overlay', 'mauna'),
		// 	'validate' => '',
		// 	'required' => array('mauna_home_video_overlay', '!=', 'none'),
		// ),

		array(
			'id' => 'mauna_home_mask',
			'title' => __('Select mask', 'mauna'),
			'type'     => 'image_select',
			// 'required' => array('mauna_home_video_overlay', '=', 'mask'),
			'tiles' => true,
			'width' => 100,
			'height' => 100,
			'options'  => array(
				'0'      => array(
					'img'   => '',
				),
				'1'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/01.png',
				),
				'2'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/02.png',
				),
				'3'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/03.png',
				),
				'4'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/04.png',
				),
				'5'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/05.png',
				),
				'6'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/06.png',
				),
				'7'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/07.png',
				),
				'8'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/08.png',
				),
				'9'      => array(
					'img'   => get_template_directory_uri().'/assets/images/overlay/09.png',
				)
			),
			'default' => '0'
		),

		array(
			'id' => 'mauna_home_background_revslider',
			'type' => 'select',
			'title' => __('Select Revolution Slider', 'mauna'),
			'options' => mauna_get_rev_sliders_array(),
			'required' => array('mauna_home_background_type', '=', 'revslider'),
			'select2'  => array( 'allowClear' => false ),
		),
		)
	);
	
	$home2 = array();
	$home2[] =  array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-address-book',
		'fields'        => array(
			array(
				'id' => 'mauna_home2_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'none',
			),
		)
	);


	$blog = array();
	$blog[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-address-book',
		'fields'        => array(
			array(
				'id' => 'mauna_blog_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-dark',
			),
			array(
				'id' => 'mauna_blog_categories',
				'title' => __( 'Blog categories', 'mauna' ),
				'subtitle' => __('Select categories to display. Empty will display all available categories.', 'mauna'),
				'type' => 'select',
				'data' => 	'categories',
				'multi' => true,
			),
		),
	);

	$gallery_item = array();
	$gallery_item[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-home',
		'fields'        => array(
			array(
				'id' => 'mauna_portfolio_single_navigation',
				'type' => 'select',
				'title' => __('Select single portfolio navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id' => 'mauna_portfolio_single_intro',
				'title' => __( 'Show featured image', 'mauna' ),
				'subtitle' => __('Select if single portfolio should contain featured image as intro.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id' => 'mauna_portfolio_single_title',
				'title' => __( 'Show title on featured image', 'mauna' ),
				'subtitle' => __('Select if intro should contain title.', 'mauna'),
				'type' => 'switch',
				'default' => true,
				'required' => array( 'mauna_portfolio_single_intro', '=', true )
			),
			array(
				'id'       => 'mauna_portfolio_single_title_font_size',
				'title' => __( 'Title on featured image font size', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'typography',
				'google' => false,
				'font-style' => false,
				'font-weight' => false,
				'font-family' => false,
				'subset' => false,
				'line-height' => false,
				// 'letter-spacing' => true,
				'color' => false,
				'text-align' => false,
				'default' => '',
				'required' => array( 'mauna_portfolio_single_title', '=', true )
			),
			array(
				'id'       => 'mauna_portfolio_single_title_letter_spacing',
				'title' => __( 'Title on featured image letter spacing (in px).', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '',
				'required' => array( 'mauna_portfolio_single_title', '=', true )
			),
			array(
				'id' => 'mauna_portfolio_item_gallery',
				'title' => __( 'Gallery', 'mauna' ),
				'type' => 'gallery',
			),
			array(
				'id' => 'mauna_portfolio_video',
				'title' => __( 'Youtube/Vimeo video link', 'mauna' ),
				'subtitle' => __('Add link if gallery lightbox should contain video.', 'mauna'),
				'type' => 'multi_text',
				// 'validate' => 'url'	
			),
			array(
				'id' => 'mauna_portfolio_single_show_first',
				'title' => __( 'Show first:', 'mauna' ),
				'subtitle' => __('Select which option will be shown first.', 'mauna'),
				'type' => 'button_set',
				'options' => array(
					'gallery' => __( 'Gallery' , 'mauna'),
					'video' => __( 'Video' , 'mauna'),
				),
				'default' => 'gallery',
				'required' => array( 'mauna_portfolio_video', '!=', '' )
			),
		),
	);

	$promotion_item = array();
	$promotion_item[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-home',
		'fields'        => array(
			array(
				'id' => 'mauna_promotion_item_title',
				'title' => __( 'Announcement title', 'mauna' ),
				'type' => 'editor',
				'args'   => array(
					'media_buttons' => false, 'textarea_rows' => 1, 'teeny' => false, 'tinymce' => array('toolbar1'=> 'styleselect,formatselect,bold,italic,strikethrough,underline,alignleft,aligncenter,alignright','toolbar2' => '')
				),
			),
			array(
				'id' => 'mauna_promotion_item_desc',
				'title' => __( 'Announcement description', 'mauna' ),
				'type' => 'editor',
				'args'   => array(
					'media_buttons' => false, 'textarea_rows' => 1, 'teeny' => false, 'tinymce' => array('toolbar1'=> 'styleselect,formatselect,bold,italic,strikethrough,underline,alignleft,aligncenter,alignright','toolbar2' => '')
				),
			),
			array(
				'id' => 'mauna_promotion_item_link',
				'title' => __( 'Announcement link', 'mauna' ),
				'type' => 'button_set',
				'options' => array(
					'link_post' => __( 'Link to post' , 'mauna'),
					'custom_link' => __( 'Custom link' , 'mauna'),
					'disable_link' => __( 'Disable link' , 'mauna')
				),
				'default' => 'link_post'
			),
			array(
				'id' => 'mauna_promotion_item_link_custom',
				'title' => __( 'Custom link', 'mauna' ),
				'type' => 'text',
				'default' => '',
				'required' => array( 'mauna_promotion_item_link', '=', 'custom_link' )
			),
		),
	);

	$about = array();
	$about[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-pencil',
		'fields'        => array(
			array(
				'id' => 'mauna_about_categories',
				'title' => __( 'About categories', 'mauna' ),
				'subtitle' => __('Select categories to display. Empty will display all available categories.', 'mauna'),
				'type' => 'select',
				'data' => 	'terms',
				'args' => array(
					'taxonomies' => 'mauna_about_categories',
				),
				'sortable' => true,
				'multi' => true,
			),
			array(
				'id'       => 'mauna_about_title_font_size',
				'title' => __( 'Title font size', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'typography',
				'google' => false,
				'font-style' => false,
				'font-weight' => false,
				'font-family' => false,
				'subset' => false,
				'line-height' => false,
				// 'letter-spacing' => true,
				'color' => false,
				'text-align' => false,
				'default' => '',
				'output' => array('.about-content-wrapper h3'),
			),
			array(
				'id'       => 'mauna_about_title_letter_spacing',
				'title' => __( 'Title letter spacing (in px).', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '',
			),
		)
	);
	$about_item = array();
	$about_item[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-home',
		'fields'        => array(
			array(
				'id' => 'mauna_about_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id'       => 'mauna_about_post_type',
				'type'     => 'button_set',
				'title'    => __( 'Post type', 'mauna' ),
				'subtitle' => __( 'Select post type for about page.', 'mauna' ),
				'options'  => array(
					'standard' => __('Standard', 'mauna'),
					'video' => __('Video', 'mauna'),
				),
				'default' => 'standard'
				// 'output'   => array('background-color'=>'.about-section .section-overlay'),
			),
			array(
				'id' => 'mauna_about_video_link',
				'type' => 'text',
				'title' => __('YouTube video link', 'mauna'),
				'required' => array('mauna_about_post_type', '=', 'video'),
			),

			array(
				'id' => 'mauna_about_video_start',
				'type' => 'text',
				'title' => __('Start video at (in seconds)', 'mauna'),
				'default' => '0',
				'required' => array('mauna_about_post_type', '=', 'video'),
			),
			array(
				'id' => 'mauna_about_video_mute',
				'type' => 'checkbox',
				'title' => __('Mute video', 'mauna'),
				'required' => array('mauna_about_post_type', '=', 'video'),
				'default' => 1,
			),
			array(
				'id' => 'mauna_about_video_mask',
				'title' => __('Select mask', 'mauna'),
				'type'     => 'image_select',
				// 'required' => array('mauna_home_video_overlay', '=', 'mask'),
				'tiles' => true,
				'width' => 100,
				'height' => 100,
				'options'  => array(
					'0'      => array(
						'img'   => '',
					),
					'1'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/01.png',
					),
					'2'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/02.png',
					),
					'3'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/03.png',
					),
					'4'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/04.png',
					),
					'5'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/05.png',
					),
					'6'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/06.png',
					),
					'7'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/07.png',
					),
					'8'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/08.png',
					),
					'9'      => array(
						'img'   => get_template_directory_uri().'/assets/images/overlay/09.png',
					)
				),
				'default' => '0',
				'required' => array('mauna_about_post_type', '=', 'video')
			),
			array(
				'id'       => 'mauna_about_content_position',
				'type'     => 'button_set',
				'title'    => __( 'Content position', 'mauna' ),
				'subtitle' => __( 'Select position for content.', 'mauna' ),
				'options'  => array(
					'pos_left' => __('Left', 'mauna'),
					'pos_center' => __('Center', 'mauna'),
					'pos_right' => __('Right', 'mauna'),
					'pos_none' => __('None', 'mauna')
				),
				'default' => 'pos_left'
				// 'output'   => array('background-color'=>'.about-section .section-overlay'),
			),
			array(
				'id' => 'mauna_about_open_overlay',
				'title' => __( 'Overlay content', 'mauna' ),
				'subtitle' => __('Select if overlay should open at start.', 'mauna'),
				'type' => 'button_set',
				'options'  => array(
					'true' => __('On', 'mauna'),
					'false' => __('Off', 'mauna'),
				),
				'default' => 'true',
				'required' => array( 'mauna_about_content_position', '!=', 'pos_none' )
			),
			
			array(
				'id'       => 'mauna_about_overlay_content_color',
				'type'     => 'color',
				'title'    => __( 'Overlay color for content', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for overlay.', 'mauna' ),
				'default'  => 'rgba(0,0,0,.5)',
				'validate' => '',
				'required' => array( 'mauna_about_content_position', '!=', 'pos_none' )
				// 'output'   => array('background-color'=>'.about-section .half-overlay'),
			),
			array(
				'id'       => 'mauna_about_txt_color',
				'type'     => 'color',
				'title'    => __( 'Content color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for about page content text', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				'required' => array( 'mauna_about_content_position', '!=', 'pos_none' )
				// 'output'   => array('color'=>'.about-section, .about-section a, #fp-nav li:before', 'background-color' => '#fp-nav li .active:after' ),
			),
			array(
				'id'       => 'mauna_about_hover_color',
				'type'     => 'color',
				'title'    => __( 'Content accent & hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for content hover & separator', 'mauna' ),
				'default'  => '#55DAA5',
				'validate' => '',
				'required' => array( 'mauna_about_content_position', '!=', 'pos_none' )
				// 'output'   => array('background'=>'.about-section .separator-color, .about-section .link-hover:before, #fp-nav li:after', 'stroke' => '.about .arrow-hover line, .about .nav-slider-arrows:hover svg'),
			),	
			array(
				'id'       => 'mauna_about_overlay_color',
				'type'     => 'color',
				'title'    => __( 'Overlay color for background image', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for overlay.', 'mauna' ),
				'default'  => 'rgba(0,0,0,.5)',
				'validate' => '',
				// 'output'   => array('background-color'=>'.about-section .section-overlay'),
			),
			array(
				'id'       => 'mauna_about_txt_color2',
				'type'     => 'color',
				'title'    => __( 'Elements color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for pagination & buttons', 'mauna' ),
				'default'  => '#fff',
				'validate' => '',
				// 'output'   => array('color'=>'.about-section, .about-section a, #fp-nav li:before', 'background-color' => '#fp-nav li .active:after' ),
			),
			// array(
			// 	'id'       => 'mauna_about_accent_color',
			// 	'type'     => 'color',
			// 	'title'    => __( 'Accent color', 'mauna' ),
			// 	'subtitle' => __( 'Select color and opacity for separator', 'mauna' ),
			// 	'default'  => '#55DAA5',
			// 	'validate' => '',
			// 	// 'output'   => array('background'=>'.about-section .separator-color, .about-section .link-hover:before, #fp-nav li:after', 'stroke' => '.about .arrow-hover line, .about .nav-slider-arrows:hover svg'),
			// ),	
			
			array(
				'id'       => 'mauna_about_hover_color2',
				'type'     => 'color',
				'title'    => __( 'Elements hover color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for pagination & buttons "open/close content" hover', 'mauna' ),
				'default'  => '#000',
				'validate' => '',
				// 'output'   => array('background'=>'.about-section .separator-color, .about-section .link-hover:before, #fp-nav li:after', 'stroke' => '.about .arrow-hover line, .about .nav-slider-arrows:hover svg'),
			),	
			array(
				'id'       => 'mauna_about_arrow_bg_color',
				'type'     => 'color',
				'title'    => __( 'Button "next slide" background color', 'mauna' ),
				'subtitle' => __( 'Select color and opacity for button background', 'mauna' ),
				'default'  => 'rgba(0,0,0,0.3)',
				'validate' => '',
				// 'output'   => array('background-color'=>'.about .nav-slider-arrows'),
			),		
			// array(
			// 	'id'       => 'mauna_about_arrow_color',
			// 	'type'     => 'color',
			// 	'title'    => __( 'Button "next slide" color', 'mauna' ),
			// 	'subtitle' => __( 'Select color and opacity for about page hover', 'mauna' ),
			// 	'default'  => '#111',
			// 	'validate' => '',
			// 	// 'output'   => array('stroke' => '.about .nav-slider-arrows svg'),
			// ),	
		),
	);

	$portfolio = array();
	$portfolio[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-pencil',
		'fields'        => array(
			array(
				'id' => 'mauna_portfolio_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id' 	  => 'mauna_portfolio_type',
				'type' 	  => 'button_set',
				'title'   => __( 'Portfolio type', 'mauna' ),
				'subtitle' => __('Field description', 'mauna'),
				'options' => array(
					'posts_gallery'  => __( 'Create portfolio from posts', 'mauna' ),
					'custom_gallery' => __( 'Create portfolio from images', 'mauna' ),
				),
				'default' => 'posts_gallery',
				
			),
			array(
				'id' 	  => 'mauna_portfolio_single_open',
				'type' 	  => 'button_set',
				'title'   => __( 'Open in:', 'mauna' ),
				'options' => array(
					'lightbox' => __( 'lightbox', 'mauna' ),
					'single_post'  => __( 'single post', 'mauna' ),
				),
				'default' => 'lightbox',
				'required' => array('mauna_portfolio_type', 'not', 'custom_gallery'),
				
			),
			array(
				'id' => 'mauna_portfolio_categories',
				'title' => __( 'Portfolio categories', 'mauna' ),
				'subtitle' => __('Select categories to display. Empty will display all available categories.', 'mauna'),
				'type' => 'select',
				'data' => 	'terms',
				'args' => array(
					'taxonomies' => 'mauna_portfolio_categories',
				),
				'multi' => true,
				'required' => array('mauna_portfolio_type', 'not', 'custom_gallery'),
			),
			array(
				'id' => 'mauna_portfolio_custom',
				'title' => __( 'Upload images', 'mauna' ),
				'subtitle' => __('Select images to display.', 'mauna'),
				'type' => 'gallery',
				'required' => array('mauna_portfolio_type', 'not', 'posts_gallery'),
			),
			array(
				'id' => 'mauna_portfolio_nav_list',
				'title' => __( 'Portfolio filters', 'mauna' ),
				'subtitle' => __('Select navigation to display.', 'mauna'),
				'type' => 'select',
				'data' => 'menus',
			),
		)
	);
	
	$portfolio2 = array();
	$portfolio2[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-pencil',
		'fields'        => array(
			array(
				'id' => 'mauna_portfolio2_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id' 	  => 'mauna_portfolio2_type',
				'type' 	  => 'button_set',
				'title'   => __( 'Portfolio type', 'mauna' ),
				'subtitle' => __('Field description', 'mauna'),
				'options' => array(
					'posts_gallery'  => __( 'Create portfolio from posts', 'mauna' ),
					'custom_gallery' => __( 'Create portfolio from images', 'mauna' ),
				),
				'default' => 'posts_gallery',
				
			),
			array(
				'id' 	  => 'mauna_portfolio2_single_open',
				'type' 	  => 'button_set',
				'title'   => __( 'Open in:', 'mauna' ),
				'options' => array(
					'lightbox' => __( 'lightbox', 'mauna' ),
					'single_post'  => __( 'single post', 'mauna' ),
				),
				'default' => 'lightbox',
				'required' => array('mauna_portfolio2_type', 'not', 'custom_gallery'),
				
			),
			array(
				'id' => 'mauna_portfolio2_categories',
				'title' => __( 'Portfolio categories', 'mauna' ),
				'subtitle' => __('Select categories to display. Empty will display all available categories.', 'mauna'),
				'type' => 'select',
				'data' => 	'terms',
				'args' => array(
					'taxonomies' => 'mauna_portfolio_categories',
				),
				'multi' => true,
				'required' => array('mauna_portfolio2_type', 'not', 'custom_gallery'),
			),
			array(
				'id' => 'mauna_portfolio2_custom',
				'title' => __( 'Upload images', 'mauna' ),
				'subtitle' => __('Select images to display.', 'mauna'),
				'type' => 'gallery',
				'required' => array('mauna_portfolio2_type', 'not', 'posts_gallery'),
			),
			array(
				'id' => 'mauna_portfolio2_nav_list',
				'title' => __( 'Portfolio filters', 'mauna' ),
				'subtitle' => __('Select navigation to display.', 'mauna'),
				'type' => 'select',
				'data' => 'menus',
				// 'required' => array('mauna_portfolio2_type', 'not', 'custom_gallery'),
			),
			// array(
			// 	'id' => 'mauna_portfolio2_lightbox_open',
			// 	'title' => __( 'Portfolio lightbox', 'mauna' ),
			// 	'subtitle' => __('Open lightbox after click in photo.', 'mauna'),
			// 	'type' => 'checkbox',
			// 	'default' => 1
			// ),
		)
	);

	$portfolio3 = array();
	$portfolio3[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-pencil',
		'fields'        => array(
			array(
				'id' => 'mauna_portfolio3_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id'       => 'mauna_portfolio3_posts_per_page',
				'type'     => 'text',
				'title'    => __( 'Images per page', 'mauna' ),
				'subtitle' => __( 'Type how many images / posts will be shown in gallery. Any images after this number will be available after clicking "Load more"', 'mauna' ),
				'default' => '9',
			),
			array(
				'id' => 'mauna_portfolio3_columns_count',
				'title' => __( 'Number of columns', 'mauna' ),
				'subtitle' => __('Select number of columns for bigger displays. Lower screens will use predefined sizes.', 'mauna'),
				'type' => 'button_set',
				'options' => array(
					'3' => __( 'Three columns' , 'mauna'),
					'4' => __( 'Four columns' , 'mauna'),
				),
				'default' => '4'
			),
			array(
				'id' => 'mauna_portfolio3_item_gutter',
				'title' => __( 'Spacing between items', 'mauna' ),
				'subtitle' => __('Add spacing between items in pixels. Empty will display default setting.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '10'
			),
			array(
				'id' 	  => 'mauna_portfolio3_type',
				'type' 	  => 'button_set',
				'title'   => __( 'Portfolio type', 'mauna' ),
				'subtitle' => __('Field description', 'mauna'),
				'options' => array(
					'posts_gallery'  => __( 'Create portfolio from posts', 'mauna' ),
					'custom_gallery' => __( 'Create portfolio from images', 'mauna' ),
				),
				'default' => 'posts_gallery',
				
			),
			array(
				'id' 	  => 'mauna_portfolio3_single_open',
				'type' 	  => 'button_set',
				'title'   => __( 'Open in:', 'mauna' ),
				'options' => array(
					'lightbox' => __( 'lightbox', 'mauna' ),
					'single_post'  => __( 'single post', 'mauna' ),
				),
				'default' => 'lightbox',
				'required' => array('mauna_portfolio3_type', 'not', 'custom_gallery'),
				
			),
			array(
				'id' => 'mauna_portfolio3_categories',
				'title' => __( 'Portfolio categories', 'mauna' ),
				'subtitle' => __('Select categories to display. Empty will display all available categories.', 'mauna'),
				'type' => 'select',
				'data' => 	'terms',
				'args' => array(
					'taxonomies' => 'mauna_portfolio_categories',
				),
				'multi' => true,
				'required' => array('mauna_portfolio3_type', 'not', 'custom_gallery'),
			),
			array(
				'id' => 'mauna_portfolio3_custom',
				'title' => __( 'Upload images', 'mauna' ),
				'subtitle' => __('Select images to display.', 'mauna'),
				'type' => 'gallery',
				'required' => array('mauna_portfolio3_type', 'not', 'posts_gallery'),
			),
			array(
				'id' => 'mauna_portfolio3_nav_list',
				'title' => __( 'Portfolio filters', 'mauna' ),
				'subtitle' => __('Select navigation to display.', 'mauna'),
				'type' => 'select',
				'data' => 'menus',
				// 'required' => array('mauna_portfolio3_type', 'not', 'custom_gallery'),
			),
		)
	);

	$portfolio4 = array();
	$portfolio4[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-pencil',
		'fields'        => array(
			array(
				'id' => 'mauna_portfolio4_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id'       => 'mauna_portfolio4_posts_per_page',
				'type'     => 'text',
				'title'    => __( 'Images per page', 'mauna' ),
				'subtitle' => __( 'Type how many images / posts will be shown in gallery. Any images after this number will be available after clicking "Load more"', 'mauna' ),
				'default' => '9',
			),
			array(
				'id' => 'mauna_portfolio4_columns_count',
				'title' => __( 'Number of columns', 'mauna' ),
				'subtitle' => __('Select number of columns for bigger displays. Lower screens will use predefined sizes.', 'mauna'),
				'type' => 'button_set',
				'options' => array(
					'3' => __( 'Three columns' , 'mauna'),
					'4' => __( 'Four columns' , 'mauna'),
				),
				'default' => '4'
			),
			array(
				'id' => 'mauna_portfolio4_item_gutter',
				'title' => __( 'Spacing between items', 'mauna' ),
				'subtitle' => __('Add spacing between items in pixels. Empty will display default setting.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '10'
			),
			array(
				'id' 	  => 'mauna_portfolio4_type',
				'type' 	  => 'button_set',
				'title'   => __( 'Portfolio type', 'mauna' ),
				'subtitle' => __('Field description', 'mauna'),
				'options' => array(
					'posts_gallery'  => __( 'Create portfolio from posts', 'mauna' ),
					'custom_gallery' => __( 'Create portfolio from images', 'mauna' ),
				),
				'default' => 'posts_gallery',
				
			),
			array(
				'id' 	  => 'mauna_portfolio4_single_open',
				'type' 	  => 'button_set',
				'title'   => __( 'Open in:', 'mauna' ),
				'options' => array(
					'lightbox' => __( 'lightbox', 'mauna' ),
					'single_post'  => __( 'single post', 'mauna' ),
				),
				'default' => 'lightbox',
				'required' => array('mauna_portfolio4_type', 'not', 'custom_gallery'),
				
			),
			array(
				'id' => 'mauna_portfolio4_categories',
				'title' => __( 'Portfolio categories', 'mauna' ),
				'subtitle' => __('Select categories to display. Empty will display all available categories.', 'mauna'),
				'type' => 'select',
				'data' => 	'terms',
				'args' => array(
					'taxonomies' => 'mauna_portfolio_categories',
				),
				'multi' => true,
				'required' => array('mauna_portfolio4_type', 'not', 'custom_gallery'),
			),
			array(
				'id' => 'mauna_portfolio4_custom',
				'title' => __( 'Upload images', 'mauna' ),
				'subtitle' => __('Select images to display.', 'mauna'),
				'type' => 'gallery',
				'required' => array('mauna_portfolio4_type', 'not', 'posts_gallery'),
			),
			array(
				'id' => 'mauna_portfolio4_nav_list',
				'title' => __( 'Portfolio filters', 'mauna' ),
				'subtitle' => __('Select navigation to display.', 'mauna'),
				'type' => 'select',
				'data' => 'menus',
				// 'required' => array('mauna_portfolio3_type', 'not', 'custom_gallery'),
			),
		)
	);

	$promotion = array();
	$promotion[] = array(
		'icon_class'    => 'icon-large',
		'icon'          => 'el-icon-pencil',
		'fields'        => array(
			array(
				'id' => 'mauna_promotion_navigation',
				'type' => 'select',
				'title' => __('Select navigation type', 'mauna'),
				'options'  => array(
					'none' => __('None', 'mauna'),
					'large-light' => __('Light large', 'mauna'),
					'small-light' => __('Light small', 'mauna'),
					'large-dark' => __('Dark large', 'mauna'),
					'small-dark' => __('Dark small', 'mauna'),
				),
				'select2' => array('allowClear'=>false),
				'default' => 'small-light',
			),
			array(
				'id' => 'mauna_promotion_nav_list',
				'title' => __( 'Navigation for content', 'mauna' ),
				'subtitle' => __('Select navigation to display.', 'mauna'),
				'type' => 'select',
				'data' => 'menus',
			),
			array(
				'id'       => 'mauna_promotion_title_enable',
				'title' => __( 'Show title', 'mauna' ),
				'subtitle' => __('Select if default template should contain title.', 'mauna'),
				'type' => 'switch',
				'default' => true,
			),
			array(
				'id'       => 'mauna_promotion_title_font_size',
				'title' => __( 'Title font size', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'typography',
				'google' => false,
				'font-style' => false,
				'font-weight' => false,
				'font-family' => false,
				'subset' => false,
				'line-height' => false,
				// 'letter-spacing' => true,
				'color' => false,
				'text-align' => false,
				'default' => '',
				'output' => array('.default-header.promotion-news-header h3'),
				'required' => array( 'mauna_promotion_title_enable', '=', true )
			),
			array(
				'id'       => 'mauna_promotion_title_letter_spacing',
				'title' => __( 'Title letter spacing (in px).', 'mauna' ),
				'subtitle' => __('Empty will display default settings.', 'mauna'),
				'type' => 'text',
				'validate' => 'numeric',
				'default' => '',
				'required' => array( 'mauna_promotion_title_enable', '=', true )
			),
			array(
				'id' => 'mauna_promotion_categories',
				'title' => __( 'Announcements categories', 'mauna' ),
				'subtitle' => __('Select categories to display. Empty will display all available categories.', 'mauna'),
				'type' => 'select',
				'data' => 	'terms',
				'args' => array(
					'taxonomies' => 'mauna_promotion_categories',
				),
				'multi' => true,
			),
		)
	);

	$seo = array();
	$seo[] = array(
		'icon' => 'el-icon-search-alt',
		'fields' => array(
			array(
				'id'       => 'mauna_seo_description_overwrite',
				'type'     => 'textarea',
				'title'    => __( 'Page meta description', 'mauna' ),
				'subtitle'     => __( 'Sentence describing page, best if between 150-160 characters.', 'mauna' ),
				'rows'     => 3
			),
			array(
				'id'       => 'mauna_seo_keywords_overwrite',
				'type'     => 'textarea',
				'title'    => __( 'Page meta keywords', 'mauna' ),
				'subtitle' => __( 'Comma separated keywords', 'mauna' ),
				'rows'     => 3
			),
			array(
				'id'       => 'mauna_og-post_object-desc',
				'type'     => 'textarea',
				'title'    => __( 'OGP Description', 'mauna' ),
				'rows'     => 3
			),
		)
	);


	$metaboxes[] = array(
		'id'            => 'page-options',
		'title'         => __( 'Default Page Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('default'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $page,
	);

	$metaboxes[] = array(
		'id'            => 'default-options',
		'title'         => __( 'Horizontal Split Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/horizontal.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $default_page,
	);
	$metaboxes[] = array(
		'id'            => 'default2-options',
		'title'         => __( 'Vertical Split Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/default.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $default2_page,
	);
	$metaboxes[] = array(
		'id'            => 'home-options',
		'title'         => __( 'Home Page Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/home.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $home,
	);
	$metaboxes[] = array(
		'id'            => 'home2-options',
		'title'         => __( 'Home Page Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/home2.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $home2,
	);
	$metaboxes[] = array(
		'id'            => 'blog_options',
		'title'         => __( 'Blog Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/blog.php'),
		//'post_format' => array('image'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $blog,
	);

	$metaboxes[] = array(
		'id'            => 'portfolio-options',
		'title'         => __( 'Gallery Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/portfolio.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $portfolio,
	);	
	$metaboxes[] = array(
		'id'            => 'portfolio2-options',
		'title'         => __( 'Gallery Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/portfolio2.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $portfolio2,
	);	

	$metaboxes[] = array(
		'id'            => 'portfolio3-options',
		'title'         => __( 'Gallery Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/portfolio3.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $portfolio3,
	);	

	$metaboxes[] = array(
		'id'            => 'portfolio4-options',
		'title'         => __( 'Gallery Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/portfolio4.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $portfolio4,
	);	

	$metaboxes[] = array(
		'id'            => 'promotion-options',
		'title'         => __( 'Announcements Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/news.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $promotion,
	);	

	$metaboxes[] = array(
		'id'            => 'gallery_item-options',
		'title'         => __( 'Portfolio Options', 'mauna' ),
		'post_types'    => array( 'mauna_portfolio_item' ),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $gallery_item,
	);
	$metaboxes[] = array(
		'id'            => 'promotion_item-options',
		'title'         => __( 'Announcements Options', 'mauna' ),
		'post_types'    => array( 'mauna_promotion_item' ),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $promotion_item,
	);
	$metaboxes[] = array(
		'id'            => 'about_item-options',
		'title'         => __( 'About Options', 'mauna' ),
		'post_types'    => array( 'mauna_about_item' ),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $about_item,
	);
	$metaboxes[] = array(
		'id'            => 'about-options',
		'title'         => __( 'About Options', 'mauna' ),
		'post_types'    => array( 'page' ),
		'page_template' => array('page-templates/about.php'),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $about,
	);	

	$metaboxes[] = array(
		'id'            => 'seo-options',
		'title'         => __( 'SEO Options', 'mauna' ),
		'post_types'    => array( 'post', 'page' ),
		'position'      => 'normal', // normal, advanced, side
		'priority'      => 'high', // high, core, default, low
		'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
		'sections'      => $seo,
	);


	// Kind of overkill, but ahh well.  ;)
	//$metaboxes = apply_filters( 'your_custom_redux_metabox_filter_here', $metaboxes );

	return $metaboxes;
  }
  add_action('redux/metaboxes/'.$redux_opt_name.'/boxes', 'redux_add_metaboxes');
endif;





// The loader will load all of the extensions automatically based on your $redux_opt_name
require_once(dirname(__FILE__).'/loader.php');